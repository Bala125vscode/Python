const state = {
    fileOld: null,
    fileNew: null,
    results: null,
    sessionId: null,
    metrics: {
        pages: 0,
        changes: 0,
        inserts: 0,
        deletes: 0
    }
};

// DOM Elements
const dropOld = document.getElementById('dropOld');
const dropNew = document.getElementById('dropNew');
const inputOld = document.getElementById('inputOld');
const inputNew = document.getElementById('inputNew');
const nameOld = document.getElementById('nameOld');
const nameNew = document.getElementById('nameNew');
const startBtn = document.getElementById('startCompare');
const modal = document.getElementById('uploadModal');
const loader = document.getElementById('loader');

// Event Listeners - Click
dropOld.onclick = () => inputOld.click();
dropNew.onclick = () => inputNew.click();

inputOld.onchange = (e) => handleFile(e.target.files[0], 'old');
inputNew.onchange = (e) => handleFile(e.target.files[0], 'new');

// Event Listeners - Drag & Drop
[dropOld, dropNew].forEach(zone => {
    zone.ondragover = (e) => {
        e.preventDefault();
        zone.style.borderColor = 'var(--accent-blue)';
        zone.style.background = '#f0f7ff';
    };
    zone.ondragleave = () => {
        zone.style.borderColor = 'var(--border-light)';
        zone.style.background = 'transparent';
    };
    zone.ondrop = (e) => {
        e.preventDefault();
        zone.style.borderColor = 'var(--border-light)';
        zone.style.background = 'transparent';
        const file = e.dataTransfer.files[0];
        handleFile(file, zone === dropOld ? 'old' : 'new');
    };
});

function handleFile(file, type) {
    if (!file) return;
    if (type === 'old') {
        state.fileOld = file;
        nameOld.innerText = file.name;
        document.getElementById('labelOld').innerText = file.name;
    } else {
        state.fileNew = file;
        nameNew.innerText = file.name;
        document.getElementById('labelNew').innerText = file.name;
    }
    startBtn.disabled = !(state.fileOld && state.fileNew);
}

startBtn.onclick = async () => {
    const formData = new FormData();
    formData.append('file1', state.fileOld);
    formData.append('file2', state.fileNew);

    loader.style.display = 'flex';

    try {
        const response = await fetch('/compare', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();
        renderResults(data);
        modal.style.display = 'none';
    } catch (err) {
        alert('Comparison failed: ' + err.message);
    } finally {
        loader.style.display = 'none';
    }
};

async function renderResults(data) {
    state.sessionId = data.session_id;
    state.results = data.comparison;

    const containerOld = document.getElementById('containerOld');
    const containerNew = document.getElementById('containerNew');
    const changesList = document.getElementById('changesList');

    containerOld.innerHTML = containerNew.innerHTML = changesList.innerHTML = '';
    state.metrics = { pages: state.results.length, changes: 0, inserts: 0, deletes: 0 };

    state.results.forEach((page, idx) => {
        const createWrap = (container, side) => {
            const wrap = document.createElement('div');
            wrap.className = 'pdf-page-wrapper placeholder';
            wrap.id = `wrapper-${side}-${idx}`;
            wrap.dataset.index = idx;
            wrap.style.minHeight = '800px';
            wrap.style.width = '600px';
            container.appendChild(wrap);
        };
        createWrap(containerOld, 'old');
        createWrap(containerNew, 'new');
        if (page.has_diff) state.metrics.changes++;
    });

    updateSummary();
    setupObserver();
}

function updateSummary() {
    document.getElementById('totalPages').innerText = state.metrics.pages;
    document.getElementById('totalChanges').innerText = state.metrics.changes;
    document.getElementById('navMaxPages').innerText = state.metrics.pages;
    document.getElementById('pageCountOld').innerText = `Pages 1 to ${state.metrics.pages}`;
    document.getElementById('pageCountNew').innerText = `Pages 1 to ${state.metrics.pages}`;
}

function setupObserver() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const idx = parseInt(entry.target.dataset.index);
                loadPage(idx);
                observer.unobserve(entry.target);
            }
        });
    }, { root: null, rootMargin: '800px', threshold: 0.1 });
    document.querySelectorAll('.pdf-page-wrapper.placeholder').forEach(p => observer.observe(p));
}

async function loadPage(idx) {
    const oldWrap = document.getElementById(`wrapper-old-${idx}`);
    const newWrap = document.getElementById(`wrapper-new-${idx}`);

    try {
        const response = await fetch(`/page/${state.sessionId}/${idx + 1}`);
        const data = await response.json();

        const scale = 600 / data.width;
        const h = data.height * scale;

        [oldWrap, newWrap].forEach(w => {
            w.style.height = `${h}px`;
            w.classList.remove('placeholder');
        });

        if (data.img_old) oldWrap.innerHTML = `<img src="data:image/png;base64,${data.img_old}" class="pdf-page fade-in">`;
        if (data.img_new) newWrap.innerHTML = `<img src="data:image/png;base64,${data.img_new}" class="pdf-page fade-in">`;

        // Render Overlays
        if (data.h_old && data.h_old.length > 0) {
            renderHighlights(oldWrap, data.h_old, 'h-del', scale);
        }
        if (data.h_new && data.h_new.length > 0) {
            renderHighlights(newWrap, data.h_new, 'h-ins', scale);
        }

        if (data.text_diff) processTextDiffs(data.text_diff, idx);
    } catch (err) {
        console.error('Failed to load page', idx, err);
    }
}

function renderHighlights(container, rects, className, scale) {
    const overlay = document.createElement('div');
    overlay.className = 'highlight-overlay';
    rects.forEach(r => {
        const rect = document.createElement('div');
        rect.className = `h-rect ${className}`;
        rect.style.left = `${r[0] * scale}px`;
        rect.style.top = `${r[1] * scale}px`;
        rect.style.width = `${Math.max(2, (r[2] - r[0]) * scale)}px`;
        rect.style.height = `${Math.max(2, (r[3] - r[1]) * scale)}px`;
        overlay.appendChild(rect);
    });
    container.appendChild(overlay);
}

function processTextDiffs(diffs, pageIdx) {
    diffs.forEach(d => {
        const type = d[0];
        const text = d[1].trim();
        if (!text || text.length < 1) return;

        if (type === 1) { // Insert
            state.metrics.inserts++;
            addChangeCard(pageIdx, 'ADDED', null, text);
        } else if (type === -1) { // Delete
            state.metrics.deletes++;
            addChangeCard(pageIdx, 'REMOVED', text, null);
        }

        document.getElementById('totalInserts').innerText = state.metrics.inserts;
        document.getElementById('totalDeletes').innerText = state.metrics.deletes;
    });
}

function addChangeCard(pageIdx, type, before, after) {
    const list = document.getElementById('changesList');
    const card = document.createElement('div');
    card.className = 'change-card fade-in';

    let labelClass = 'label-replaced';
    if (type === 'ADDED') labelClass = 'label-added';
    if (type === 'REMOVED') labelClass = 'label-removed';

    card.innerHTML = `
        <div class="change-label ${labelClass}">${type}</div>
        ${before ? `<div class="card-text"><b>Before:</b><div class="snippet-del">${before}</div></div>` : ''}
        ${after ? `<div class="card-text"><b>After:</b><div class="snippet-ins">${after}</div></div>` : ''}
    `;

    card.onclick = () => scrollToPage(pageIdx);
    list.appendChild(card);
    document.getElementById('changeCounter').innerText = `${list.children.length} total changes`;
}

function scrollToPage(index) {
    const paneOld = document.getElementById('paneOld');
    const target = document.getElementById(`wrapper-old-${index}`);
    if (target) {
        paneOld.scrollTo({ top: target.offsetTop - 20, behavior: 'smooth' });
    }
}

// Sync Scrolling
const paneOld = document.getElementById('paneOld');
const paneNew = document.getElementById('paneNew');
let isScrolling = false;

paneOld.onscroll = () => {
    if (!isScrolling) {
        isScrolling = true;
        paneNew.scrollTop = paneOld.scrollTop;
        setTimeout(() => isScrolling = false, 20);
    }
};

paneNew.onscroll = () => {
    if (!isScrolling) {
        isScrolling = true;
        paneOld.scrollTop = paneNew.scrollTop;
        setTimeout(() => isScrolling = false, 20);
    }
};

document.getElementById('newComparison').onclick = () => location.reload();
lucide.createIcons();
