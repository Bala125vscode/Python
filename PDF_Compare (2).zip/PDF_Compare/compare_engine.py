import fitz  # PyMuPDF
from diff_match_patch import diff_match_patch
from PIL import Image, ImageChops, ImageDraw
import io
import base64

class PDFCompareEngine:
    def __init__(self):
        self.dmp = diff_match_patch()

    def get_text_diff(self, text1, text2):
        diffs = self.dmp.diff_main(text1, text2)
        self.dmp.diff_cleanupSemantic(diffs)
        return diffs

    def compare_pages_visually(self, page1, page2, zoom=2.0):
        mat = fitz.Matrix(zoom, zoom)
        pix1 = page1.get_pixmap(matrix=mat)
        pix2 = page2.get_pixmap(matrix=mat)
        img1 = Image.open(io.BytesIO(pix1.tobytes()))
        img2 = Image.open(io.BytesIO(pix2.tobytes()))
        
        if img1.size != img2.size:
            img2 = img2.resize(img1.size)
            
        diff = ImageChops.difference(img1, img2)
        if diff.getbbox():
            diff_mask = diff.convert('L').point(lambda x: 255 if x > 10 else 0)
            highlight = Image.new('RGB', img1.size, (255, 0, 0))
            result = Image.composite(highlight, img2, diff_mask)
            result = Image.blend(img2.convert('RGB'), result, 0.4)
            buffered = io.BytesIO()
            result.save(buffered, format="PNG")
            return base64.b64encode(buffered.getvalue()).decode()
        return None

    def analyze_documents(self, file1_path, file2_path):
        d1 = fitz.open(file1_path)
        d2 = fitz.open(file2_path)
        results = []
        num_pages = max(len(d1), len(d2))
        for i in range(num_pages):
            page_data = {"page_num": i + 1, "has_diff": False, "status": "Equal"}
            p1 = d1[i] if i < len(d1) else None
            p2 = d2[i] if i < len(d2) else None
            if p1 and p2:
                if p1.get_text() != p2.get_text():
                    page_data["has_diff"] = True
                    page_data["status"] = "Changed"
                else:
                    pix1 = p1.get_pixmap(matrix=fitz.Matrix(0.2, 0.2))
                    pix2 = p2.get_pixmap(matrix=fitz.Matrix(0.2, 0.2))
                    if pix1.tobytes() != pix2.tobytes():
                        page_data["has_diff"] = True
                        page_data["status"] = "Changed"
            elif p1:
                page_data["has_diff"] = True
                page_data["status"] = "Deleted"
            else:
                page_data["has_diff"] = True
                page_data["status"] = "Added"
            results.append(page_data)
        d1.close()
        d2.close()
        return results

    def get_page_details(self, file1_path, file2_path, page_idx):
        doc1 = fitz.open(file1_path)
        doc2 = fitz.open(file2_path)
        page_data = {
            "img_old": None, "img_new": None, "visual_diff": None, "text_diff": None,
            "width": 0, "height": 0, "h_old": [], "h_new": []
        }
        p1 = doc1[page_idx] if page_idx < len(doc1) else None
        p2 = doc2[page_idx] if page_idx < len(doc2) else None
        
        if p1:
            page_data["width"], page_data["height"] = p1.rect.width, p1.rect.height
        elif p2:
            page_data["width"], page_data["height"] = p2.rect.width, p2.rect.height

        mat = fitz.Matrix(2.0, 2.0)
        if p1:
            pix1 = p1.get_pixmap(matrix=mat)
            page_data["img_old"] = base64.b64encode(pix1.tobytes()).decode()
        if p2:
            pix2 = p2.get_pixmap(matrix=mat)
            page_data["img_new"] = base64.b64encode(pix2.tobytes()).decode()
        
        if p1 and p2:
            text1 = p1.get_text()
            text2 = p2.get_text()
            diffs = self.get_text_diff(text1, text2)
            page_data["text_diff"] = diffs
            
            # Map diffs to coordinates using search_for with quad results
            for d in diffs:
                tag, chunk = d[0], d[1]
                if tag == -1 and len(chunk.strip()) > 0:
                    # PyMuPDF search_for is generally reliable if we search for the specific chunk
                    rects = p1.search_for(chunk)
                    for r in rects:
                        page_data["h_old"].append([r.x0, r.y0, r.x1, r.y1])
                elif tag == 1 and len(chunk.strip()) > 0:
                    rects = p2.search_for(chunk)
                    for r in rects:
                        page_data["h_new"].append([r.x0, r.y0, r.x1, r.y1])

            v_diff = self.compare_pages_visually(p1, p2, zoom=2.0)
            if v_diff:
                page_data["visual_diff"] = v_diff
                
        doc1.close()
        doc2.close()
        return page_data
