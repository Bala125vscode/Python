
import sys
import os

# Ensure app module can be found
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app.converter import LatexConverter

try:
    c = LatexConverter()
    input_path = os.path.join(os.path.dirname(__file__), 'repro_units.tex')
    with open(input_path, 'r') as f:
        content = f.read()
    converted = c.convert(content)
    print(converted)
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
