import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from app.converter import LatexConverter

def test_robustness():
    conv = LatexConverter()
    
    # Test cases for math wrapping
    test_cases = [
        # Outside math
        (r"The unit is \unit{\meter}", r"The unit is $\mathrm{m}$"),
        (r"Acceleration is \qty{9.8}{\meter\per\second\squared}", r"Acceleration is $9.8\,\mathrm{ms}^{-2}$"),
        
        # Inside math ($)
        (r"Math: $\unit{\meter}$", r"Math: $\mathrm{m}$"),
        (r"Math: $ \qty{5}{\volt} $", r"Math: $ 5\,\mathrm{V} $"),
        
        # Inside display math ($$)
        (r"$$ \unit{\ohm} $$", r"$$ \Omega $$"),
        
        # Inside environments
        (r"\begin{equation} \unit{\joule} \end{equation}", r"\begin{equation} \mathrm{J} \end{equation}"),
        
        # Complex mix
        (r"Text1 \num{123} Text2 $ \num{456} $", r"Text1 $123$ Text2 $ 456 $"),
        
        # New units
        (r"\unit{\byte}", r"$\mathrm{B}$"),
        (r"\unit{\parsec}", r"$\mathrm{pc}$"),
        (r"\unit{\kibi\byte}", r"$\mathrm{KiB}$"),
        
        # Physunits specials
        (r"\Celsius", r"$^{\circ}\mathrm{C}$"),
        (r"\Volt", r"$\mathrm{V}$"),
    ]
    
    for inp, expected in test_cases:
        out = conv.convert(inp)
        if out == expected:
            print(f"PASS: {inp} -> {out}")
        else:
            print(f"FAIL: {inp}")
            print(f"  Expected: {expected}")
            print(f"  Got:      {out}")

if __name__ == "__main__":
    test_robustness()
