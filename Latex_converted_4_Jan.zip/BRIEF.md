# Project Brief: LaTeX Converter

## Overview
The **LaTeX Converter** is a specialized utility designed to bridge the gap between high-level LaTeX packages (`siunitx`, `physics`) and standard, portable LaTeX syntax. It is particularly useful for authors submitting to journals or publishers that do not support specialized packages or require raw LaTeX for their production pipelines.

## Core Problem
- **Portability**: LaTeX documents using `siunitx` or `physics` often fail to compile on systems lacking these packages.
- **Publisher Constraints**: Many publishers require documents to be "flattened" into standard LaTeX macros (`\mathrm`, `\frac`, etc.).
- **Consistency**: Manual conversion of units and derivatives is error-prone and time-consuming.

## Our Solution
A robust, regex-powered engine that:
1.  Parses complex unit structures (prefixes, base units, exponents, and modifiers).
2.  Handles physics-specific notation (differentials, bras, kets, vectors).
3.  Automatically detects math mode context to avoid redundant delimiters.
4.  Groups consecutive formatting commands for cleaner output (e.g., `\mathrm{nm}`).
5.  Provides a web-based "Conversion Workbench" with real-time diffing.

## Target Audience
- Researchers and Academics.
- Scientific Publishers.
- LaTeX Template Developers.

## Technology Stack
- **Backend**: FastAPI (Python 3.8+).
- **Core Engine**: Custom token-based regex parser.
- **Frontend**: Vanilla HTML/CSS/JS with Jinja2 templates.
- **Packaging**: Standard Python dependencies (`uvicorn`, `aiofiles`, etc.).
