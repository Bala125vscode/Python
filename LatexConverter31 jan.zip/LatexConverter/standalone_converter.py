
import re
import sys
import tkinter as tk
from tkinter import filedialog, messagebox
import os
import traceback

# ------------------------------------------------------------------------------
# UNIT_MAP and PREFIX_SET (Bundled from app/units.py)
# ------------------------------------------------------------------------------

UNIT_MAP = {
    # SI Base Units
    r'\meter': r'\mathrm{m}', r'\metre': r'\mathrm{m}', r'\m': r'\mathrm{m}',
    r'\kilogram': r'\mathrm{kg}', r'\kg': r'\mathrm{kg}', r'\gram': r'\mathrm{g}',
    r'\second': r'\mathrm{s}', r'\s': r'\mathrm{s}',
    r'\ampere': r'\mathrm{A}', r'\A': r'\mathrm{A}',
    r'\candela': r'\mathrm{cd}', r'\cd': r'\mathrm{cd}',
    r'\kelvin': r'\mathrm{K}', r'\K': r'\mathrm{K}',
    r'\mole': r'\mathrm{mol}', r'\mol': r'\mathrm{mol}',
    r'\gram': r'\mathrm{g}', r'\g': r'\mathrm{g}',

    # Derived Units
    r'\becquerel': r'\mathrm{Bq}',
    r'\degreeCelsius': r'^{\circ}\mathrm{C}', r'\celsius': r'^{\circ}\mathrm{C}',
    r'\coulomb': r'\mathrm{C}',
    r'\farad': r'\mathrm{F}', r'\F': r'\mathrm{F}',
    r'\gray': r'\mathrm{Gy}',
    r'\hertz': r'\mathrm{Hz}', r'\Hz': r'\mathrm{Hz}',
    r'\henry': r'\mathrm{H}', r'\H': r'\mathrm{H}',
    r'\joule': r'\mathrm{J}', r'\J': r'\mathrm{J}',
    r'\katal': r'\mathrm{kat}',
    r'\lumen': r'\mathrm{lm}', r'\lm': r'\mathrm{lm}',
    r'\lux': r'\mathrm{lx}', r'\lx': r'\mathrm{lx}',
    r'\newton': r'\mathrm{N}', r'\N': r'\mathrm{N}',
    r'\ohm': r'\Omega', r'\Ohm': r'\Omega',
    r'\pascal': r'\mathrm{Pa}', r'\Pa': r'\mathrm{Pa}',
    r'\radian': r'\mathrm{rad}',
    r'\siemens': r'\mathrm{S}', r'\S': r'\mathrm{S}',
    r'\sievert': r'\mathrm{Sv}',
    r'\steradian': r'\mathrm{sr}',
    r'\tesla': r'\mathrm{T}', r'\T': r'\mathrm{T}',
    r'\volt': r'\mathrm{V}', r'\V': r'\mathrm{V}',
    r'\watt': r'\mathrm{W}', r'\W': r'\mathrm{W}',
    r'\weber': r'\mathrm{Wb}', r'\Wb': r'\mathrm{Wb}',

    # Additional Units
    r'\arcmin': r'^{\prime}', r'\arcminute': r'^{\prime}',
    r'\arcsec': r'^{\prime\prime}', r'\arcsecond': r'^{\prime\prime}',
    r'\degree': r'^{\circ}',
    r'\astronomicalunit': r'\mathrm{au}',
    r'\atomicmassunit': r'\mathrm{u}',
    r'\barn': r'\mathrm{b}',
    r'\bel': r'\mathrm{B}', r'\decibel': r'\mathrm{dB}', r'\dB': r'\mathrm{dB}',
    r'\day': r'\mathrm{d}',
    r'\hectare': r'\mathrm{ha}',
    r'\hour': r'\mathrm{h}', r'\hr': r'\mathrm{h}',
    r'\litre': r'\mathrm{l}', r'\liter': r'\mathrm{L}', r'\l': r'\mathrm{L}', r'\L': r'\mathrm{L}',
    r'\minute': r'\mathrm{min}', r'\min': r'\mathrm{min}',
    r'\percent': r'\%',
    r'\tonne': r'\mathrm{t}',
    r'\dalton': r'\mathrm{Da}',
    r'\electronvolt': r'\mathrm{eV}', r'\eV': r'\mathrm{eV}',
    r'\elementarycharge': r'\mathrm{e}',
    r'\gauss': r'\mathrm{G}',
    r'\torr': r'\mathrm{Torr}',
    r'\parsec': r'\mathrm{pc}',
    r'\lightyear': r'\mathrm{ly}',
    r'\bit': r'\mathrm{bit}',
    r'\byte': r'\mathrm{B}',
    r'\curie': r'\mathrm{Ci}',
    r'\gal': r'\mathrm{Gal}',
    r'\roentgen': r'\mathrm{R}',
    r'\rem': r'\mathrm{rem}',
    r'\molar': r'\mathrm{M}', r'\Molar': r'\mathrm{M}',
    r'\neper': r'\mathrm{Np}',

    # Abbreviations - Extra
    r'\amu': r'\mathrm{u}',
    r'\cm': r'\mathrm{cm}',
    r'\mm': r'\mathrm{mm}',
    r'\nm': r'\mathrm{nm}',
    r'\um': r'\mu\mathrm{m}',
    r'\pm': r'\mathrm{pm}',
    r'\kHz': r'\mathrm{kHz}',
    r'\MHz': r'\mathrm{MHz}',
    r'\GHz': r'\mathrm{GHz}',
    r'\THz': r'\mathrm{THz}',
    r'\mA': r'\mathrm{mA}',
    r'\kA': r'\mathrm{kA}',
    r'\uA': r'\mu\mathrm{A}',
    r'\nA': r'\mathrm{nA}',
    r'\pA': r'\mathrm{pA}',
    r'\mV': r'\mathrm{mV}',
    r'\kV': r'\mathrm{kV}',
    r'\uW': r'\mu\mathrm{W}',
    r'\mW': r'\mathrm{mW}',
    r'\kW': r'\mathrm{kW}',
    r'\MW': r'\mathrm{MW}',
    r'\GW': r'\mathrm{GW}',
    r'\uJ': r'\mu\mathrm{J}',
    r'\mJ': r'\mathrm{mJ}',
    r'\kJ': r'\mathrm{kJ}',
    r'\MJ': r'\mathrm{MJ}',
    r'\kWh': r'\mathrm{kW\,h}',
    r'\meV': r'\mathrm{meV}',
    r'\keV': r'\mathrm{keV}',
    r'\MeV': r'\mathrm{MeV}',
    r'\GeV': r'\mathrm{GeV}',
    r'\TeV': r'\mathrm{TeV}',
    r'\fF': r'\mathrm{fF}',
    r'\pF': r'\mathrm{pF}',
    r'\nF': r'\mathrm{nF}',
    r'\uF': r'\mu\mathrm{F}',
    r'\mF': r'\mathrm{mF}',
    r'\fH': r'\mathrm{fH}',
    r'\pH': r'\mathrm{pH}',
    r'\nH': r'\mathrm{nH}',
    r'\uH': r'\mu\mathrm{H}',
    r'\mH': r'\mathrm{mH}',
    r'\nC': r'\mathrm{nC}',
    r'\mC': r'\mathrm{mC}',
    r'\uC': r'\mu\mathrm{C}',
    r'\mT': r'\mathrm{mT}',
    r'\uT': r'\mu\mathrm{T}',

    # Binary Prefixes
    r'\kibi': r'\mathrm{Ki}',
    r'\mebi': r'\mathrm{Mi}',
    r'\gibi': r'\mathrm{Gi}',
    r'\tebi': r'\mathrm{Ti}',
    r'\pebi': r'\mathrm{Pi}',
    r'\exbi': r'\mathrm{Ei}',
    r'\zebi': r'\mathrm{Zi}',
    r'\yobi': r'\mathrm{Yi}',

    # physunits specials
    r'\gm': r'\mathrm{g}',
    r'\Sec': r'\mathrm{s}',
    r'\Min': r'\mathrm{min}',
    r'\Day': r'\mathrm{d}',
    r'\Volt': r'\mathrm{V}',
    r'\Coulomb': r'\mathrm{C}',
    r'\Amp': r'\mathrm{A}',
    r'\Farad': r'\mathrm{F}',
    r'\Tesla': r'\mathrm{T}',
    r'\Gauss': r'\mathrm{G}',
    r'\Henry': r'\mathrm{H}',
    r'\Joule': r'\mathrm{J}',
    r'\Watt': r'\mathrm{W}',
    r'\Newton': r'\mathrm{N}',
    r'\Kelvin': r'\mathrm{K}',
    r'\Celsius': r'^{\circ}\mathrm{C}',
    r'\Fahrenheit': r'^{\circ}\mathrm{F}',
    r'\Rankine': r'\mathrm{R}',
    r'\calorie': r'\mathrm{cal}',
    r'\kcal': r'\mathrm{kcal}',
    r'\barP': r'\mathrm{bar}',
    r'\atm': r'\mathrm{atm}',
    r'\mmHg': r'\mathrm{mmHg}',
    r'\inHg': r'\mathrm{inHg}',
    r'\lbsi': r'\mathrm{psi}',
    r'\lbsf': r'\mathrm{psf}',
    r'\Torr': r'\mathrm{Torr}',

    # Prefixes (standalone)
    r'\quecto': r'\mathrm{q}',
    r'\ronto': r'\mathrm{r}',
    r'\yocto': r'\mathrm{y}',
    r'\zepto': r'\mathrm{z}',
    r'\atto': r'\mathrm{a}',
    r'\femto': r'\mathrm{f}',
    r'\pico': r'\mathrm{p}',
    r'\nano': r'\mathrm{n}',
    r'\micro': r'\mu',
    r'\milli': r'\mathrm{m}',
    r'\centi': r'\mathrm{c}',
    r'\deci': r'\mathrm{d}',
    r'\deca': r'\mathrm{da}',
    r'\deka': r'\mathrm{da}',
    r'\hecto': r'\mathrm{h}',
    r'\kilo': r'\mathrm{k}',
    r'\mega': r'\mathrm{M}',
    r'\giga': r'\mathrm{G}',
    r'\tera': r'\mathrm{T}',
    r'\peta': r'\mathrm{P}',
    r'\exa': r'\mathrm{E}',
    r'\zetta': r'\mathrm{Z}',
    r'\yotta': r'\mathrm{Y}',
    r'\ronna': r'\mathrm{R}',
    r'\quetta': r'\mathrm{Q}',

    r'\per': r'/', 
    r'\squared': r'^2',
    r'\cubed': r'^3',
}

PREFIX_SET = {
    r'\quecto', r'\ronto', r'\yocto', r'\zepto', r'\atto', r'\femto', 
    r'\pico', r'\nano', r'\micro', r'\milli', r'\centi', r'\deci',
    r'\deca', r'\deka', r'\hecto', r'\kilo', r'\mega', r'\giga',
    r'\tera', r'\peta', r'\exa', r'\zetta', r'\yotta', r'\ronna', r'\quetta',
    r'\kibi', r'\mebi', r'\gibi', r'\tebi', r'\pebi', r'\exbi', r'\zebi', r'\yobi'
}

# ------------------------------------------------------------------------------
# LatexConverter Class (Bundled from app/converter.py)
# ------------------------------------------------------------------------------

class LatexConverter:
    def __init__(self):
        # Compile regex for unit mapping
        sorted_keys = sorted(UNIT_MAP.keys(), key=len, reverse=True)
        patterns = []
        for key in sorted_keys:
            esc = re.escape(key)
            # If key is like \word (letters only), add boundary check
            # to prevent \m matching start of \meter or \text
            if re.match(r"\\[a-zA-Z]+$", key):
                patterns.append(esc + r"(?![a-zA-Z])")
            else:
                patterns.append(esc)
        
        self.unit_pattern = re.compile('|'.join(patterns))

    def _tokenize_unit(self, unit_str):
        """
        Tokenizes unit string into commands and text.
        Returns list of (type, value) tuples.
        types: 'CMD', 'TEXT', 'ARG'
        """
        tokens = []
        i = 0
        n = len(unit_str)
        while i < n:
            char = unit_str[i]
            if char == '\\':
                j = i + 1
                while j < n and unit_str[j].isalpha():
                    j += 1
                cmd = unit_str[i:j]
                tokens.append(('CMD', cmd))
                i = j
            elif char == '{':
                arg, end = self._extract_braced_content(unit_str, i)
                if arg is not None:
                    tokens.append(('ARG', arg))
                    i = end + 1
                else:
                    tokens.append(('TEXT', char))
                    i += 1
            elif char.isspace():
                i += 1
            else:
                tokens.append(('TEXT', char))
                i += 1
        return tokens

    def _map_unit(self, unit_str):
        """
        Maps siunitx unit macros to standard LaTeX text commands.
        """
        if unit_str in UNIT_MAP:
            return UNIT_MAP[unit_str]

        tokens = self._tokenize_unit(unit_str)
        unit_blocks = []
        
        sign = 1
        next_power = None
        current_prefixes = []
        
        i = 0
        while i < len(tokens):
            typ, val = tokens[i]
            
            if typ == 'CMD':
                if val == '\\per':
                    sign = -1
                elif val == '\\square':
                    next_power = 2
                elif val == '\\cubic':
                    next_power = 3
                elif val == '\\raiseto':
                    if i + 1 < len(tokens) and tokens[i+1][0] == 'ARG':
                        next_power = tokens[i+1][1]
                        i += 1
                elif val in UNIT_MAP:
                    if val in PREFIX_SET:
                        current_prefixes.append(UNIT_MAP[val])
                    else:
                        p = 1
                        if next_power is not None:
                            p = next_power
                            next_power = None
                        
                        j = i + 1
                        suffix_power = None
                        while j < len(tokens):
                            styp, sval = tokens[j]
                            if styp == 'CMD':
                                if sval == '\\tothe':
                                    if j + 1 < len(tokens) and tokens[j+1][0] == 'ARG':
                                        suffix_power = tokens[j+1][1]
                                        j += 1
                                    j += 1
                                    i = j - 1
                                    continue
                                elif sval in ['\\squared', '\\square']:
                                    suffix_power = 2
                                    j += 1
                                    i = j - 1
                                    continue
                                elif sval in ['\\cubed', '\\cubic']:
                                    suffix_power = 3
                                    j += 1
                                    i = j - 1
                                    continue
                            break
                        
                        if suffix_power is not None:
                            p = suffix_power
                        
                        exponent = ""
                        try:
                           fp = float(p)
                           total = fp * sign
                           if total != 1:
                                if total == int(total):
                                    total_str = str(int(total))
                                else:
                                    total_str = str(total)
                                exponent = f"^{{{total_str}}}"
                        except ValueError:
                           if sign == -1:
                               exponent = f"^{{-{p}}}"
                           else:
                               exponent = f"^{{{p}}}"
                        
                        block = "".join(current_prefixes) + UNIT_MAP[val] + exponent
                        unit_blocks.append(block)
                        current_prefixes = []
                elif val == '\\text':
                     if i + 1 < len(tokens) and tokens[i+1][0] == 'ARG':
                         unit_blocks.append(f"\\text{{{tokens[i+1][1]}}}")
                         i += 1
                elif val == r'\to':
                    unit_blocks.append(r'\text{to}')
                elif val == r'\C':
                     unit_blocks.append(r'\mathrm{C}')
                
            elif typ == 'TEXT' and val.strip():
                formatted = ""
                parts = re.split(r'([a-zA-Z]+)', val)
                for part in parts:
                    if part.isalpha():
                        formatted += f"\\mathrm{{{part}}}"
                    else:
                        formatted += part
                unit_blocks.append(formatted)
            
            i += 1
            
        res = "".join(unit_blocks)
        while True:
             new_res = re.sub(r'\\mathrm\{([^{}]+)\}\\mathrm\{([^{}]+)\}', r'\\mathrm{\1\2}', res)
             if new_res == res:
                 break
             res = new_res
             
        return res

    def _extract_braced_content(self, text, start_index):
        if start_index >= len(text) or text[start_index] != '{':
            return None, -1

        balance = 0
        for i in range(start_index, len(text)):
            char = text[i]
            if char == '{':
                balance += 1
            elif char == '}':
                balance -= 1
                if balance == 0:
                    return text[start_index+1:i], i
        return None, -1

    def _extract_optional_arg(self, text, start_index):
        i = start_index
        while i < len(text) and text[i].isspace():
            i += 1
        
        if i >= len(text) or text[i] != '[':
            return None, start_index

        balance = 0
        for j in range(i, len(text)):
            char = text[j]
            if char == '[':
                balance += 1
            elif char == ']':
                balance -= 1
                if balance == 0:
                    return text[i+1:j], j
        return None, start_index

    def _parse_number(self, num_str):
        num_str = num_str.replace('+/-', '\\pm ').replace('+-', '\\pm ')
        match = re.search(r'(?<=[\d\.])[eE]([+-]?\d+)\b', num_str)
        if match:
            exp = match.group(1)
            base = num_str[:match.start()]
            return f"{base} \\times 10^{{{exp}}}"
        return num_str

    def _parse_complex(self, content):
        content = re.sub(r'(?<!\\)(\d+|\b)[ij]\b', r'\1\\mathrm{i}', content)
        if r'\angle' in content:
            parts = content.split(r'\angle')
            if len(parts) == 2:
                mag = self._parse_number(parts[0].strip())
                phase = self._parse_number(parts[1].strip())
                return f"{mag} \\angle {phase}^{{\\circ}}"
        return self._parse_number(content)

    def _parse_list(self, content, unit=None):
        items = content.split(';')
        parsed_items = [self._parse_number(item.strip()) for item in items]
        if len(parsed_items) == 0:
            return ""
        res = ""
        if len(parsed_items) == 1:
            res = parsed_items[0]
        elif len(parsed_items) == 2:
            res = f"{parsed_items[0]} \\text{{ and }} {parsed_items[1]}"
        else:
            res = ", ".join(parsed_items[:-1]) + f" \\text{{ and }} {parsed_items[-1]}"
        if unit:
            res += f"\\,{self._map_unit(unit)}"
        return res

    def _parse_product(self, content, unit=None):
        items = content.split('x')
        parsed_items = [self._parse_number(item.strip()) for item in items]
        res = " \\times ".join(parsed_items)
        if unit:
            res += f"\\,{self._map_unit(unit)}"
        return res

    def _parse_range(self, num1, num2, unit=None):
        n1 = self._parse_number(num1)
        n2 = self._parse_number(num2)
        res = f"{n1} \\text{{ to }} {n2}"
        if unit:
            res += f"\\,{self._map_unit(unit)}"
        return res

    def convert(self, text):
        output = []
        i = 0
        n = len(text)
        math_stack = []
        math_envs = {'equation', 'align', 'gather', 'multline', 'flalign', 'alignat', 'displaymath', 'equation*'}

        while i < n:
            if text.startswith('\\$', i):
                output.append('\\$')
                i += 2
                continue
            
            if text.startswith('$$', i):
                if math_stack and math_stack[-1] == '$$':
                    math_stack.pop()
                elif not math_stack:
                    math_stack.append('$$')
                output.append('$$')
                i += 2
                continue
            
            if text.startswith('$', i):
                if math_stack and math_stack[-1] == '$':
                    math_stack.pop()
                elif not math_stack:
                    math_stack.append('$')
                output.append('$')
                i += 1
                continue
                
            if text.startswith('\\(', i):
                math_stack.append('\\(')
                output.append('\\(')
                i += 2
                continue
            if text.startswith('\\)', i):
                if math_stack and math_stack[-1] == '\\(':
                    math_stack.pop()
                output.append('\\)')
                i += 2
                continue
            if text.startswith('\\[', i):
                math_stack.append('\\[')
                output.append('\\[')
                i += 2
                continue
            if text.startswith('\\]', i):
                if math_stack and math_stack[-1] == '\\[':
                    math_stack.pop()
                output.append('\\]')
                i += 2
                continue

            if text[i] == '\\':
                j = i + 1
                while j < n and (text[j].isalpha() or text[j] == '*'):
                    j += 1
                cmd = text[i:j]
                
                if cmd == '\\' and i + 1 < n and not text[i+1].isalpha():
                    output.append(text[i:i+2])
                    i += 2
                    continue

                def wrap_if_needed(content):
                    if not math_stack:
                        return f"${content}$"
                    return content

                if cmd == '\\num':
                    arg, end = self._extract_braced_content(text, j)
                    if arg is not None:
                        output.append(wrap_if_needed(self._parse_number(arg)))
                        i = end + 1
                        continue
                
                elif cmd == '\\complexnum':
                    arg, end = self._extract_braced_content(text, j)
                    if arg is not None:
                        output.append(wrap_if_needed(self._parse_complex(arg)))
                        i = end + 1
                        continue
                        
                elif cmd in ['\\unit', '\\si']:
                    _, opt_end = self._extract_optional_arg(text, j)
                    arg, end = self._extract_braced_content(text, opt_end + 1 if opt_end != j else j)
                    if arg is not None:
                        output.append(wrap_if_needed(self._map_unit(arg)))
                        i = end + 1
                        continue

                elif cmd in ['\\qty', '\\SI']:
                    _, opt_end = self._extract_optional_arg(text, j)
                    num_arg, end1 = self._extract_braced_content(text, opt_end + 1 if opt_end != j else j)
                    if num_arg is not None:
                        unit_arg, end2 = self._extract_braced_content(text, end1 + 1)
                        if unit_arg is not None:
                            output.append(wrap_if_needed(f"{self._parse_number(num_arg)}\\,{self._map_unit(unit_arg)}"))
                            i = end2 + 1
                            continue

                elif cmd in ['\\numlist', '\\numproduct']:
                    _, opt_end = self._extract_optional_arg(text, j)
                    arg, end = self._extract_braced_content(text, opt_end + 1 if opt_end != j else j)
                    if arg is not None:
                        res = self._parse_list(arg) if cmd == '\\numlist' else self._parse_product(arg)
                        output.append(wrap_if_needed(res))
                        i = end + 1
                        continue

                elif cmd in ['\\qtylist', '\\qtyproduct']:
                    _, opt_end = self._extract_optional_arg(text, j)
                    arg1, end1 = self._extract_braced_content(text, opt_end + 1 if opt_end != j else j)
                    if arg1 is not None:
                        arg2, end2 = self._extract_braced_content(text, end1 + 1)
                        if arg2 is not None:
                            res = self._parse_list(arg1, unit=arg2) if cmd == '\\qtylist' else self._parse_product(arg1, unit=arg2)
                            output.append(wrap_if_needed(res))
                            i = end2 + 1
                            continue

                elif cmd in ['\\numrange', '\\SIrange', '\\qtyrange']:
                    _, opt_end = self._extract_optional_arg(text, j)
                    arg1, end1 = self._extract_braced_content(text, opt_end + 1 if opt_end != j else j)
                    if arg1 is not None:
                        arg2, end2 = self._extract_braced_content(text, end1 + 1)
                        if arg2 is not None:
                            if cmd == '\\numrange':
                                res = self._parse_range(arg1, arg2)
                                output.append(wrap_if_needed(res))
                                i = end2 + 1
                                continue
                            else:
                                arg3, end3 = self._extract_braced_content(text, end2 + 1)
                                if arg3 is not None:
                                    res = self._parse_range(arg1, arg2, unit=arg3)
                                    output.append(wrap_if_needed(res))
                                    i = end3 + 1
                                    continue
                        
                elif cmd == '\\ang':
                    arg, end = self._extract_braced_content(text, j)
                    if arg is not None:
                        res = ""
                        if ';' in arg:
                            parts = arg.split(';')
                            if parts[0].strip():
                                res += f"{parts[0]}^{{\\circ}}"
                            if len(parts) > 1 and parts[1].strip():
                                res += f"{parts[1]}'"
                            if len(parts) > 2 and parts[2].strip():
                                res += f"{parts[2]}''"
                        else:
                            res = f"{arg}^{{\\circ}}"
                        output.append(wrap_if_needed(res))
                        i = end + 1
                        continue

                elif cmd == '\\begin':
                    arg, end1 = self._extract_braced_content(text, j)
                    if arg == 'tabular':
                        output.append('\\begin{tabular}')
                        spec, end_spec = self._extract_braced_content(text, end1 + 1)
                        if spec is not None:
                            new_spec = spec.replace('S', 'c')
                            output.append(f"{{{new_spec}}}")
                            i = end_spec + 1
                            continue
                        else:
                            i = end1 + 1
                            continue
                    elif arg in math_envs:
                        math_stack.append(arg)
                        output.append(f"\\begin{{{arg}}}")
                        i = end1 + 1
                        continue
                    else:
                        output.append(f"\\begin{{{arg}}}")
                        i = end1 + 1
                        continue
                
                elif cmd == '\\end':
                    arg, end1 = self._extract_braced_content(text, j)
                    if math_stack and math_stack[-1] == arg:
                        math_stack.pop()
                    output.append(f"\\end{{{arg}}}")
                    i = end1 + 1
                    continue

                if cmd in UNIT_MAP:
                    output.append(wrap_if_needed(UNIT_MAP[cmd]))
                    i = j
                    continue

                elif cmd == '\\dv':
                    opt_arg, opt_end = self._extract_optional_arg(text, j)
                    arg1, end1 = self._extract_braced_content(text, opt_end + 1 if opt_end != j else j)
                    
                    if arg1 is not None:
                        arg2, end2 = self._extract_braced_content(text, end1 + 1)
                        order = f"^{opt_arg}" if opt_arg else ""
                        if arg2 is not None:
                            res = f"\\frac{{\\mathrm{{d}}{order} {arg1}}}{{\\mathrm{{d}}{arg2}{order}}}"
                            i = end2 + 1
                        else:
                            res = f"\\frac{{\\mathrm{{d}}{order}}}{{\\mathrm{{d}}{arg1}{order}}}"
                            i = end1 + 1
                        output.append(wrap_if_needed(res))
                        continue

                elif cmd == '\\pdv':
                    opt_arg, opt_end = self._extract_optional_arg(text, j)
                    arg1, end1 = self._extract_braced_content(text, opt_end + 1 if opt_end != j else j)
                    
                    if arg1 is not None:
                        arg2, end2 = self._extract_braced_content(text, end1 + 1)
                        order = f"^{opt_arg}" if opt_arg else ""
                        if arg2 is not None:
                            res = f"\\frac{{\\partial{order} {arg1}}}{{\\partial {arg2}{order}}}"
                            i = end2 + 1
                        else:
                            res = f"\\frac{{\\partial{order}}}{{\\partial {arg1}{order}}}"
                            i = end1 + 1
                        output.append(wrap_if_needed(res))
                        continue

                elif cmd == '\\abs':
                    arg, end = self._extract_braced_content(text, j)
                    if arg is not None:
                        output.append(wrap_if_needed(f"\\left| {arg} \\right|"))
                        i = end + 1
                        continue
                elif cmd == '\\norm':
                    arg, end = self._extract_braced_content(text, j)
                    if arg is not None:
                        output.append(wrap_if_needed(f"\\left\\| {arg} \\right\\|"))
                        i = end + 1
                        continue
                
                elif cmd == '\\vb':
                    arg, end = self._extract_braced_content(text, j)
                    if arg is not None:
                        output.append(wrap_if_needed(f"\\mathbf{{{arg}}}"))
                        i = end + 1
                        continue
                
                elif cmd == '\\bra':
                    arg, end = self._extract_braced_content(text, j)
                    if arg is not None:
                        output.append(wrap_if_needed(f"\\langle {arg} |"))
                        i = end + 1
                        continue
                elif cmd == '\\ket':
                    arg, end = self._extract_braced_content(text, j)
                    if arg is not None:
                        output.append(wrap_if_needed(f"| {arg} \\rangle"))
                        i = end + 1
                        continue
                elif cmd == '\\braket':
                    arg1, end1 = self._extract_braced_content(text, j)
                    if arg1 is not None:
                        arg2, end2 = self._extract_braced_content(text, end1 + 1)
                        if arg2 is not None:
                            output.append(wrap_if_needed(f"\\langle {arg1} | {arg2} \\rangle"))
                            i = end2 + 1
                        else:
                             output.append(wrap_if_needed(f"\\langle {arg1} | {arg1} \\rangle"))
                             i = end1 + 1
                        continue

                output.append(cmd)
                i = j
            else:
                output.append(text[i])
                i += 1
        
        return "".join(output)

# ------------------------------------------------------------------------------
# GUI Logic
# ------------------------------------------------------------------------------

def process_file():
    root = tk.Tk()
    root.withdraw() # Hide main window

    file_path = filedialog.askopenfilename(
        title="Select LaTeX File to Convert",
        filetypes=[("LaTeX Files", "*.tex"), ("All Files", "*.*")]
    )

    if not file_path:
        return

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        converter = LatexConverter()
        converted_content = converter.convert(content)

        save_path = filedialog.asksaveasfilename(
            title="Save Converted File",
            defaultextension=".tex",
            initialfile=f"converted_{os.path.basename(file_path)}",
            filetypes=[("LaTeX Files", "*.tex")]
        )

        if save_path:
            with open(save_path, "w", encoding="utf-8") as f:
                f.write(converted_content)
            
            messagebox.showinfo("Success", f"File converted and saved to:\n{save_path}")

    except Exception as e:
        traceback.print_exc()
        messagebox.showerror("Error", f"An error occurred:\n{str(e)}")

if __name__ == "__main__":
    process_file()
