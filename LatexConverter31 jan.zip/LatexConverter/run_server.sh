#!/bin/bash

# Check if python is installed
if ! command -v python3 &> /dev/null
then
    echo "python3 could not be found. Please install it."
    exit
fi

# Install dependencies if needed
echo "Installing dependencies..."
pip install -r requirements.txt

# Start the server
echo "Starting LatexConverter..."
python3 run.py
