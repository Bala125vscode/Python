
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from app.converter import LatexConverter

try:
    c = LatexConverter()
    with open('tests/gap_analysis.tex', 'r') as f:
        content = f.read()
    converted = c.convert(content)
    print(converted)
except Exception as e:
    print(e)
    sys.exit(1)
