
import unittest
from app.converter import LatexConverter

class TestFeedbackRepro(unittest.TestCase):
    def setUp(self):
        self.converter = LatexConverter()

    def test_redundant_dollars(self):
        input_str = r"$\num{5408} - \num{4025.56} =  \qty{1382.44}{\kilo\electronvolt}$"
        # We want to avoid $$5408$$ etc.
        # It should ideally be $5408 - 4025.56 = 1382.44\,\mathrm{keV}$
        result = self.converter.convert(input_str)
        print(f"DEBUG redundant_dollars: {result}")
        self.assertNotIn("$$", result)
        self.assertIn("$5408", result)

    def test_missing_mathrm_literal(self):
        input_str = r"neutron density (\unit{n/cm^3}) and motion (\unit{cm/s})"
        result = self.converter.convert(input_str)
        print(f"DEBUG missing_mathrm_literal: {result}")
        self.assertIn(r"\mathrm{n}/\mathrm{cm}^3", result)
        self.assertIn(r"\mathrm{cm}/\mathrm{s}", result)

    def test_missing_mathrm_MS(self):
        input_str = r"\SI{100}{MS\per\milli\second}"
        result = self.converter.convert(input_str)
        print(f"DEBUG missing_mathrm_MS: {result}")
        self.assertIn(r"\mathrm{MS}", result)

    def test_sirange_delimiter(self):
        input_str = r"{\SIrange{0}{5}{\volt}}"
        result = self.converter.convert(input_str)
        print(f"DEBUG sirange_delimiter: {result}")
        # User wants "to" instead of "--"
        self.assertIn(r"0 \text{ to } 5", result)

    def test_per_mode_symbol(self):
        # Even if we don't parse the preamble, let's see if we can handle \per as / if requested
        # Or maybe it's a default change to make it more standard?
        # The user's example was: \si{\kelvin\per\watt} -> converted \mathrm{KW}^{-1} (wrong, want slash?)
        input_str = r"\si{\kelvin\per\watt}"
        result = self.converter.convert(input_str)
        print(f"DEBUG per_mode_symbol: {result}")
        # If per-mode=symbol, it should be K/W?
        # For now, let's see what it produces.
        
    def test_mb_spacing(self):
        input_str = r"\qty{10}{MB}"
        result = self.converter.convert(input_str)
        print(f"DEBUG mb_spacing: {result}")
        # User says tool added space between M and B.
        self.assertNotIn(r"\mathrm{M} \mathrm{B}", result)
        self.assertIn(r"\mathrm{MB}", result)

if __name__ == "__main__":
    unittest.main()
