
import unittest
from app.converter import LatexConverter

class TestLatestFeedback(unittest.TestCase):
    def setUp(self):
        self.converter = LatexConverter()

    def test_C_global_replacement(self):
        # User says "\C" is not part of siunitx/physics but tool replaced it.
        # It should probably be left alone if it's not inside a unit macro?
        input_str = r"\C"
        result = self.converter.convert(input_str)
        # Expected: \C (unchanged)
        # Actual (reported): \mathrm{C}
        self.assertEqual(result, r"\C")

    def test_to_global_replacement(self):
        # User says "\to" changed to \mathrm{to}.
        # Standard latex \to is \rightarrow.
        input_str = r"\to"
        result = self.converter.convert(input_str)
        self.assertEqual(result, r"\to")

    def test_qtyrange_delimiter(self):
        # \qtyrange{10}{30}{\MeV} -> 10 to 30 MeV
        input_str = r"\qtyrange{10}{30}{\MeV}"
        result = self.converter.convert(input_str)
        # We expect "10 \text{ to } 30\,\mathrm{MeV}"
        self.assertIn(r"\text{ to }", result)
        self.assertIn(r"\mathrm{MeV}", result)

    def test_elementary_charge(self):
        # \unit{\elementarycharge\squared} -> e^2
        # Output is \mathrm{e}^{2} which is acceptable/correct in unit context
        input_str = r"\unit{\elementarycharge\squared}"
        result = self.converter.convert(input_str)
        self.assertTrue(r"\mathrm{e}^{2}" in result or "e^{2}" in result)

if __name__ == "__main__":
    unittest.main()
