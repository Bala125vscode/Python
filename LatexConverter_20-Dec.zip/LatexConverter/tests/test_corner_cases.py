
import unittest
from app.converter import LatexConverter

class TestCornerCases(unittest.TestCase):
    def setUp(self):
        self.converter = LatexConverter()

    def test_spaces_in_input(self):
        input_str = r"\qty{1.2}{\mega \hertz}"
        expected = r"1.2\,\mathrm{MHz}"
        self.assertEqual(self.converter.convert(input_str), expected)
        
        input_str2 = r"\qty{1.2}{\mega  \hertz}"
        self.assertEqual(self.converter.convert(input_str2), expected)

    def test_chained_prefixes(self):
        # Nonsense physically but tests grouping logic
        # \kilo\mega\hertz -> \mathrm{k}\mathrm{M}\mathrm{Hz} -> \mathrm{kMHz}
        input_str = r"\qty{1}{\kilo\mega\hertz}"
        expected = r"1\,\mathrm{kMHz}"
        self.assertEqual(self.converter.convert(input_str), expected)

    def test_mixed_font_units(self):
        # \micro\meter -> \mu\mathrm{m} (No merge)
        input_str = r"\qty{1}{\micro\meter}"
        expected = r"1\,\mu\mathrm{m}"
        self.assertEqual(self.converter.convert(input_str), expected)
        
        # \kilo\ohm -> \mathrm{k}\Omega (No merge)
        input_str = r"\qty{1}{\kilo\ohm}"
        expected = r"1\,\mathrm{k}\Omega"
        self.assertEqual(self.converter.convert(input_str), expected)

    def test_prefix_with_sq_unit(self):
        # \kilo\meter\squared -> \mathrm{km}^2
        input_str = r"\qty{1}{\kilo\meter\squared}"
        expected = r"1\,\mathrm{km}^{2}"
        self.assertEqual(self.converter.convert(input_str), expected)

    def test_prefix_sq_unit_per_second(self):
        # \kilo\meter\squared\per\second -> \mathrm{km}^2\mathrm{s}^{-1} -> \mathrm{km}^{2}\mathrm{s}^{-1}
        # Merging \mathrm{km}^2 and \mathrm{s}^{-1}?
        # Exponents are outside \mathrm{...}. 
        # \mathrm{km}^{2}\mathrm{s}^{-1}.
        # Regex: \mathrm{km}^{2} ... matches \mathrm{...} followed by check for \mathrm?
        # My regex: \\mathrm\{([^{}]+)\}\\mathrm\{([^{}]+)\}
        # \mathrm{km}^{2}\mathrm{s}^{-1}
        # It sees \mathrm{km}. Next chars are ^{2}\mathrm...
        # It does NOT match because regex expects literal \mathrm immediately after }.
        # So merging across units with exponents does not happen.
        # This is ACCEPTABLE because exponents break the visual text block anyway.
        input_str = r"\qty{1}{\kilo\meter\squared\per\second}"
        expected = r"1\,\mathrm{km}^{2}\mathrm{s}^{-1}"
        self.assertEqual(self.converter.convert(input_str), expected)

    def test_consecutive_units_simple(self):
        # \newton\meter -> \mathrm{N}\mathrm{m} -> \mathrm{Nm}
        input_str = r"\qty{1}{\newton\meter}"
        expected = r"1\,\mathrm{Nm}"
        self.assertEqual(self.converter.convert(input_str), expected)

if __name__ == '__main__':
    unittest.main()
