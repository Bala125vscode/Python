
import random

def generate_large_tex(filename="large_test.tex", num_lines=1000):
    header = r"""
\documentclass{article}
\usepackage{siunitx}
\usepackage{physics}
\begin{document}
"""
    footer = r"\end{document}"
    
    units = [r"\meter", r"\kilogram", r"\second", r"\ampere", r"\kelvin", r"\mole", r"\candela", 
             r"\volt", r"\joule", r"\newton", r"\ohm", r"\pascal", r"\watt", r"\coulomb"]
    prefixes = [r"\kilo", r"\mega", r"\giga", r"\milli", r"\micro", r"\nano", r"\centi", r"\deci"]
    
    physics_cmds = [
        r"\dv{f}{x}", r"\pdv{f}{x}", r"\pdv[2]{f}{x}", r"\abs{x}", r"\norm{v}",
        r"\bra{\psi}", r"\ket{\phi}", r"\braket{\psi}{\phi}", r"\vb{E}"
    ]
    
    with open(filename, "w", encoding="utf-8") as f:
        f.write(header)
        
        for i in range(num_lines):
            # Generate random equations and sentences
            line_type = random.choice(["qty", "num", "physics", "text"])
            
            if line_type == "qty":
                val = random.uniform(0, 1000)
                prefix = random.choice(prefixes) if random.random() > 0.5 else ""
                unit = random.choice(units)
                f.write(f"Value {i}: \\qty{{{val:.2f}}}{{{prefix}{unit}}} \\\\ \n")
            
            elif line_type == "num":
                val = random.uniform(0, 100000)
                f.write(f"Number {i}: \\num{{{val:.4e}}} \\\\ \n")
                
            elif line_type == "physics":
                cmd = random.choice(physics_cmds)
                f.write(f"Equation {i}: ${cmd}$ \\\\ \n")
            
            else:
                f.write(f"Some random text line {i} with no commands. \\\\ \n")
                
        f.write(footer)

if __name__ == "__main__":
    generate_large_tex("tests/large_test.tex", num_lines=5000)
    print("Generated tests/large_test.tex")
