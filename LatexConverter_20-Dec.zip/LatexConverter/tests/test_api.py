from fastapi.testclient import TestClient
from app.main import app
import io
import zipfile

client = TestClient(app)

def test_read_root():
    response = client.get("/")
    assert response.status_code == 200
    assert "LaTeX Converter" in response.text

def test_convert_text():
    response = client.post("/convert", data={"code": r"\qty{10}{\meter}"})
    assert response.status_code == 200
    assert r"10\,\mathrm{m}" in response.text

def test_upload_file():
    tex_content = r"\documentclass{article}\usepackage{siunitx}\begin{document}\qty{10}{\kilo\gram}\end{document}"
    file_obj = io.BytesIO(tex_content.encode('utf-8'))
    files = {"file": ("test.tex", file_obj, "application/x-tex")}
    
    response = client.post("/upload", files=files)
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/zip"
    
    # Verify zip content
    with zipfile.ZipFile(io.BytesIO(response.content)) as z:
        assert "test_converted.tex" in z.namelist()
        assert "diff.html" in z.namelist()
        
        converted_tex = z.read("test_converted.tex").decode('utf-8')
        # \kilo\gram converts to \mathrm{k}\mathrm{g} (prefix + unit), which renders the same as \mathrm{kg}
        assert r"10\,\mathrm{k}\mathrm{g}" in converted_tex or r"10\,\mathrm{kg}" in converted_tex
