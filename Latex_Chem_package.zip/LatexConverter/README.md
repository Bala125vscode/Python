# LaTeX Converter

A powerful web application and Python library to convert LaTeX code using `siunitx` and `physics` packages into standard LaTeX syntax. This tool helps remove dependencies on specific packages, ensuring your LaTeX documents are more portable and compatible with various publishers' requirements.

## Features

- **Unit Conversion**: Converts `siunitx` commands like `\qty`, `\num`, `\unit` to standard LaTeX text and math mode commands.
- **Physics Macros**: Transforms `physics` package macros like `\dv`, `\pdv`, `\ket`, `\bra` to standard notation.
- **Regex-Based Replacement**: Uses advanced regex logic to handle complex nested braces and modifiers.
- **Web Interface**: User-friendly web UI built with FastAPI to paste code or upload files.
- **Diff Viewer**: visual High-contrast diff viewer to see exactly what changed (with text wrapping support).
- **ZIP Export**: Convert entire `.tex` files and download the result as a ZIP package.

## Installation

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd LatexConverter
   ```

2. **Set up a virtual environment** (optional but recommended):
   ```bash
   python -m venv venv
   # Windows
   text\Scripts\activate
   # Linux/Mac
   source venv/bin/activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

### Running the Web Server

1. **Start the server**:
   ```bash
   # Using the provided batch file (Windows)
   run_server.bat
   
   # Or directly with Python
   python run.py
   
   # Or with Uvicorn
   uvicorn app.main:app --reload
   ```

2. **Open your browser**:
   Navigate to `http://127.0.0.1:8000`.

3. **Convert Code**:
   - Paste your LaTeX snippet into the left box.
   - Click "Convert Code".
   - View the standard LaTeX output and the diff below.

### Using as a Library

You can import the `LatexConverter` class in your own Python scripts:

```python
from app.converter import LatexConverter

converter = LatexConverter()
latex_code = r"\qty{1.2}{\mega\hertz}"
standard_code = converter.convert(latex_code)
print(standard_code) # Output: 1.2\,\mathrm{MHz}
```

## Supported Transformations

- **siunitx**:
  - `\qty{...}{...}` -> `Number\,\Unit`
  - `\unit{...}` -> `\mathrm{...}`
  - Prefixes (`\kilo`, `\mega`) and Units (`\meter`, `\hertz`) are mapped to `\mathrm` equivalents.
  - Exponents and modifiers (`\squared`, `\per`) are handled correctly.

- **physics**:
  - `\dv{f}{x}` -> `\frac{\mathrm{d}f}{\mathrm{d}x}`
  - `\pdv{f}{x}` -> `\frac{\partial f}{\partial x}`
  - `\bra{a}`, `\ket{b}`, `\braket{a}{b}` -> Dirac notation with `\langle` and `\rangle`.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for details on how to run tests and contribute to the project.
