
import re
from app.converter import LatexConverter

def test_strict():
    c = LatexConverter()
    input_str = r"\qty{1.2}{\mega\hertz}"
    res = c.convert(input_str)
    print(f"Input: {input_str}")
    print(f"Result: {repr(res)}")
    
    # Debug regex separately
    test_str = r"\mathrm{M}\mathrm{Hz}"
    new_res = re.sub(r'\\mathrm\{([^{}]+)\}\\mathrm\{([^{}]+)\}', r'\\mathrm{\1\2}', test_str)
    print(f"Regex Test Input: {repr(test_str)}")
    print(f"Regex Test Output: {repr(new_res)}")
    
    if res == r"1.2\,\mathrm{MHz}":
        print("PASS")
    else:
        print("FAIL")

if __name__ == "__main__":
    test_strict()
