
import unittest
from app.converter import LatexConverter

class TestReproMegaHertz(unittest.TestCase):
    def setUp(self):
        self.converter = LatexConverter()

    def test_mega_hertz(self):
        input_str = r"\qty{1.2}{\mega\hertz}"
        # We expect \mathrm{MHz}
        expected = r"1.2\,\mathrm{MHz}"
        result = self.converter.convert(input_str)
        self.assertEqual(result, expected)

    def test_kilo_gram(self):
        input_str = r"\qty{5}{\kilo\gram}"
        expected = r"5\,\mathrm{kg}" # Wait, \kilo is k, \gram is kg?
        # units.py: \kilo -> \mathrm{k}, \gram -> \mathrm{g} (usually? let's check units.py)
        # units.py says: r'\gram': r'\mathrm{g}'
        # So \kilo\gram -> \mathrm{k}\mathrm{g} -> \mathrm{kg}
        result = self.converter.convert(input_str)
        self.assertEqual(result, expected)

    def test_micro_meter(self):
        input_str = r"\qty{10}{\micro\meter}"
        # \micro -> \mu (not \mathrm)
        # \meter -> \mathrm{m}
        # Result should be \mu\mathrm{m} - CANNOT merge \mu into \mathrm
        expected = r"10\,\mu\mathrm{m}"
        result = self.converter.convert(input_str)
        self.assertEqual(result, expected)

    def test_meter_per_second(self):
        # \meter\per\second -> \mathrm{m}\mathrm{s}^{-1} -> \mathrm{ms}^{-1}
        input_str = r"\qty{10}{\meter\per\second}"
        expected = r"10\,\mathrm{ms}^{-1}"
        result = self.converter.convert(input_str)
        self.assertEqual(result, expected)

    def test_km_squared(self):
        # \kilo\meter\squared -> \mathrm{k}\mathrm{m}^2 -> \mathrm{km}^2
        # Mathrm grouping will happen later.
        input_str = r"\qty{10}{\kilo\meter\squared}"
        expected = r"10\,\mathrm{km}^{2}"
        result = self.converter.convert(input_str)
        self.assertEqual(result, expected)

    def test_per_mega_hertz(self):
        # \per\mega\hertz -> \mathrm{MHz}^{-1}
        input_str = r"\qty{1}{\per\mega\hertz}"
        expected = r"1\,\mathrm{MHz}^{-1}" 
        result = self.converter.convert(input_str)
        self.assertEqual(result, expected)

    def test_square_prefix_issue_check(self):
         # \square\kilo\meter -> \mathrm{k}\mathrm{m}^2 -> \mathrm{km}^2
         # \square usually applies to the whole unit block in siunitx logic if prefix is attached.
         input_str = r"\qty{1}{\square\kilo\meter}"
         expected = r"1\,\mathrm{km}^{2}"
         result = self.converter.convert(input_str)
         self.assertEqual(result, expected)

if __name__ == '__main__':
    unittest.main()
