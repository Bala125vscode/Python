
import unittest
from app.converter import LatexConverter

class TestReproTask1(unittest.TestCase):
    def setUp(self):
        self.converter = LatexConverter()

    def test_nano_meter_grouping(self):
        # \nano -> \mathrm{n}
        # \meter -> \mathrm{m}
        # Result should be \mathrm{nm}, not \mathrm{n}\mathrm{m}
        # Note: \nm is already \mathrm{nm} in UNIT_MAP, so we test \nano\meter
        input_str = r"\qty{10}{\nano\meter}"
        expected = r"10\,\mathrm{nm}"
        result = self.converter.convert(input_str)
        self.assertEqual(result, expected)

    def test_three_units(self):
        # \milli\newton\meter -> \mathrm{m}\mathrm{N}\mathrm{m} -> \mathrm{mNm}
        input_str = r"\unit{\milli\newton\meter}"
        expected = r"\mathrm{mNm}"
        result = self.converter.convert(input_str)
        self.assertEqual(result, expected)

    def test_with_exponents_interfering(self):
        # \nano\squared\meter -> \mathrm{n}^2\mathrm{m} -> Should NOT merge?
        # \mathrm{n}^2\mathrm{m} is correct. Merging to \mathrm{n^2m} is wrong syntax-wise for standard LaTeX if we want math mode exponents.
        # But wait, \mathrm is text font in math mode.
        # \mathrm{n}\mathrm{m} -> \mathrm{nm} is fine.
        # \mathrm{n}^2\mathrm{m} -> cannot merge across the ^2.
        # So we only merge if they are strictly consecutive strings.
        input_str = r"\unit{\nano\squared\meter}"
        expected = r"\mathrm{n}^{2}\mathrm{m}"
        # The merge logic should NOT touch this.
        result = self.converter.convert(input_str)
        self.assertEqual(result, expected)

    def test_consecutive_mathrm_explicit(self):
        # User might have \mathrm{A}\mathrm{B} in other contexts? 
        # But the request implies the converter produces this from units.
        pass

if __name__ == '__main__':
    unittest.main()
