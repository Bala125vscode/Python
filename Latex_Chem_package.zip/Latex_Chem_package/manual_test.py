from chem_converter.core import LatexChemConverter

converter = LatexChemConverter()

test_cases = [
    (r"\ce{H2O}", r"\mathrm{H}_{2}\mathrm{O}"),
    (r"\ce{CO2}", r"\mathrm{C}\mathrm{O}_{2}"),
    (r"\ce{H+}", r"\mathrm{H}^{+}"),
    (r"\ce{SO4^2-}", r"\mathrm{S}\mathrm{O}_{4}^{2-}"),
    (r"\ce{A -> B}", r"\mathrm{A} \rightarrow \mathrm{B}")
]

print("Running manual verification...")
for input_tex, expected in test_cases:
    result = converter.convert(input_tex)
    print(f"Input:    {input_tex}")
    print(f"Output:   {result}")
    # print(f"Expected: {expected}")
    print("-" * 20)
