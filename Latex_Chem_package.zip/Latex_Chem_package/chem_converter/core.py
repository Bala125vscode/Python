from .strategies.mhchem import MhChemStrategy

class LatexChemConverter:
    def __init__(self):
        self.strategies = [
            MhChemStrategy()
        ]

    def convert(self, text: str) -> str:
        """
        Convert LaTeX text using all registered strategies.
        """
        converted_text = text
        for strategy in self.strategies:
            converted_text = strategy.convert(converted_text)
        return converted_text
