import re

class MhChemStrategy:
    def convert(self, text: str) -> str:
        """
        Convert \ce{...} commands to standard LaTeX.
        """
        # Regex to find \ce{content}
        # This is a basic implementation and might need refinement for nested braces
        pattern = r"\\ce\{([^\}]+)\}"
        
        def replace_match(match):
            content = match.group(1)
            return self._parse_formula(content)
            
        return re.sub(pattern, replace_match, text)

    def _parse_formula(self, formula: str) -> str:
        """
        Parse the chemical formula content inside \ce{...}.
        """
        # 1. Handle subscripts (numbers after letters)
        # e.g., H2O -> H_{2}O, C6H12O6 -> C_{6}H_{12}O_{6}
        formula = re.sub(r"([A-Za-z])(\d+)", r"\1_{\2}", formula)
        
        # 2. Handle charges (superscripts)
        # e.g., ^2+, ^-, +
        # This is tricky. mhchem handles 'H+', 'OH-', 'Fe^2+'
        
        # Super simple approach for + and - immediately following
        formula = re.sub(r"([A-Za-z\}])\+", r"\1^{+}", formula)
        formula = re.sub(r"([A-Za-z\}])\-", r"\1^{-}", formula)
        
        # Handle explicitly caret charges ^2+
        formula = re.sub(r"\^(\d+[-+])", r"^{\1}", formula)
        
        # 3. Handle reaction arrows
        formula = formula.replace("->", r"\rightarrow")
        formula = formula.replace("<=>", r"\rightleftharpoons")
        
        # 4. Handle state symbols (aq), (s), (l), (g) -> \text{(...)} or \mathrm{(...)}
        # We'll wrap everything in \mathrm by default for the chemical context if not math
        
        # Wrap the whole thing in \mathrm for correct font in math mode
        # BUT we need to be careful not to wrap existing commands
        
        # For now, let's wrap individual chemical species in \mathrm if they are just letters
        # This is a naive implementation; a real parser would tokenize.
        
        # Let's assume the user wants standard math mode output for the chemical equation
        return r"\mathrm{" + formula + "}"
