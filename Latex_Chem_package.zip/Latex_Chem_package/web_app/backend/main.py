from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
import shutil
import os
import tempfile
import difflib
from chem_converter.core import LatexChemConverter

app = FastAPI()

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For dev only
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="web_app/static"), name="static")
templates = Jinja2Templates(directory="web_app/templates")

converter = LatexChemConverter()

class ConversionRequest(BaseModel):
    text: str

def generate_html_diff(original: str, converted: str) -> str:
    d = difflib.HtmlDiff()
    # wrap=True ensures lines wrap and don't make the table super wide
    return d.make_file(original.splitlines(), converted.splitlines(), fromdesc="Original", todesc="Converted", context=True, numlines=5)

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/convert/text")
async def convert_text(request: ConversionRequest):
    try:
        converted = converter.convert(request.text)
        # Generate diff
        diff_html = generate_html_diff(request.text, converted)
        return {
            "original": request.text, 
            "converted": converted,
            "diff_html": diff_html
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/convert/file")
async def convert_file(file: UploadFile = File(...)):
    try:
        content = await file.read()
        text_content = content.decode("utf-8")
        converted = converter.convert(text_content)
        diff_html = generate_html_diff(text_content, converted)
        return {
            "original": text_content, 
            "converted": converted,
            "diff_html": diff_html,
            "filename": file.filename
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8081)
