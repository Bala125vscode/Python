const editor = document.getElementById('editor');
const fileUpload = document.getElementById('file-upload');
const fileNameDisplay = document.getElementById('file-name-display');

const convertBtn = document.getElementById('convert-btn');
const uploadBtn = document.getElementById('upload-btn');

const resultsPanel = document.getElementById('results-panel');
const previewArea = document.getElementById('preview-area');
const loadingOverlay = document.getElementById('loading-overlay');

const downloadTexBtn = document.getElementById('download-tex-btn');
const downloadDiffBtn = document.getElementById('download-diff-btn');

let currentResult = null;
let currentFilename = "converted_document";

const demoText = `\\documentclass{article}
\\usepackage{mhchem}
\\begin{document}
\\ce{2H2 + O2 -> 2H2O}
\\end{document}`;

// --- Event Listeners ---

// Convert Button
if (convertBtn) {
    convertBtn.addEventListener('click', processTextConversion);
}

// File Input Change
if (fileUpload) {
    fileUpload.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            if (fileNameDisplay) fileNameDisplay.innerText = file.name;
            currentFilename = file.name.replace(/\.[^/.]+$/, "");
        } else {
            if (fileNameDisplay) fileNameDisplay.innerText = "No file chosen";
        }
    });
}

// Upload & Convert Button
if (uploadBtn) {
    uploadBtn.addEventListener('click', handleUploadAndConvert);
}

// Downloads
if (downloadTexBtn) {
    downloadTexBtn.addEventListener('click', () => {
        if (!currentResult) return;
        downloadString(currentResult.converted, `${currentFilename}.tex`, 'text/plain');
    });
}

if (downloadDiffBtn) {
    downloadDiffBtn.addEventListener('click', () => {
        if (!currentResult) return;
        downloadString(currentResult.diff_html, `${currentFilename}_diff.html`, 'text/html');
    });
}


// --- Functions ---

async function processTextConversion() {
    const text = editor.value;
    if (!text.trim()) {
        alert("Please enter some LaTeX code.");
        return;
    }
    await performConversion(text);
}

async function handleUploadAndConvert() {
    const file = fileUpload.files[0];
    if (!file) {
        alert("Please select a file first.");
        return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
        const text = e.target.result;
        editor.value = text;
        await performConversion(text);
    };
    reader.readAsText(file);
}

async function performConversion(text) {
    showLoading(true);
    try {
        const response = await fetch('/convert/text', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: text })
        });

        if (!response.ok) throw new Error("Conversion failed");

        currentResult = await response.json();
        displayResults(currentResult);

    } catch (err) {
        console.error(err);
        alert("An error occurred during conversion.");
    } finally {
        showLoading(false);
    }
}

function displayResults(data) {
    // Show download buttons
    if (resultsPanel) {
        resultsPanel.classList.remove('hidden');
        resultsPanel.classList.add('flex'); // Ensure it uses flex layout
    }

    // Update Output/Preview Area
    if (previewArea) {
        previewArea.innerText = data.converted;
    }
}

function downloadString(content, filename, contentType) {
    const blob = new Blob([content], { type: contentType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function showLoading(show) {
    if (loadingOverlay) {
        if (show) loadingOverlay.classList.remove('hidden');
        else loadingOverlay.classList.add('hidden');
    }
}
