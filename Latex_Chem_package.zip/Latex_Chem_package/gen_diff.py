import difflib

original = r"""\documentclass{article}
\usepackage{mhchem}
\begin{document}
\ce{2H2 + O2 -> 2H2O}
\ce{SO4^2- + Ba^2+ -> BaSO4 v}
\end{document}"""

converted = r"""\documentclass{article}
\usepackage{mhchem}
\begin{document}
\mathrm{2H_{2} + O_{2} \rightarrow 2H_{2}O}
\mathrm{SO_{4}^{2-} + Ba^{2+} \rightarrow BaSO_{4} v}
\end{document}"""

d = difflib.HtmlDiff()
html = d.make_file(original.splitlines(), converted.splitlines(), fromdesc="Original (mhchem)", todesc="Converted (Standard)", context=True)

with open("sample_diff.html", "w") as f:
    f.write(html)
print("sample_diff.html created")
