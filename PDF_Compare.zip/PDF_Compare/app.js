const state = {
    fileOld: null,
    fileNew: null,
    results: null,
    sessionId: null,
    visualDiffEnabled: false,
    zoom: 1.0,
    metrics: {
        pages: 0,
        changes: 0,
        inserts: 0,
        deletes: 0
    }
};

// DOM Elements
const dropOld = document.getElementById('dropOld');
const dropNew = document.getElementById('dropNew');
const inputOld = document.getElementById('inputOld');
const inputNew = document.getElementById('inputNew');
const nameOld = document.getElementById('nameOld');
const nameNew = document.getElementById('nameNew');
const startBtn = document.getElementById('startCompare');
const modal = document.getElementById('uploadModal');
const loader = document.getElementById('loader');

// Event Listeners
dropOld.onclick = () => inputOld.click();
dropNew.onclick = () => inputNew.click();

inputOld.onchange = (e) => handleFile(e.target.files[0], 'old');
inputNew.onchange = (e) => handleFile(e.target.files[0], 'new');

function handleFile(file, type) {
    if (!file) return;
    if (type === 'old') {
        state.fileOld = file;
        nameOld.innerText = file.name;
        document.getElementById('labelOld').innerText = file.name;
    } else {
        state.fileNew = file;
        nameNew.innerText = file.name;
        document.getElementById('labelNew').innerText = file.name;
    }
    startBtn.disabled = !(state.fileOld && state.fileNew);
}

startBtn.onclick = async () => {
    const formData = new FormData();
    formData.append('file1', state.fileOld);
    formData.append('file2', state.fileNew);

    loader.style.display = 'flex';

    try {
        const response = await fetch('/compare', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();
        renderResults(data);
        modal.style.display = 'none';
    } catch (err) {
        alert('Comparison failed: ' + err.message);
    } finally {
        loader.style.display = 'none';
    }
};

async function renderResults(data) {
    state.sessionId = data.session_id;
    state.results = data.comparison;

    const containerOld = document.getElementById('containerOld');
    const containerNew = document.getElementById('containerNew');
    const changesList = document.getElementById('changesList');

    containerOld.innerHTML = '';
    containerNew.innerHTML = '';
    changesList.innerHTML = '';

    state.metrics = { pages: state.results.length, changes: 0, inserts: 0, deletes: 0 };

    state.results.forEach((page, idx) => {
        // Create Left Placeholder
        const pageOld = document.createElement('div');
        pageOld.className = 'pdf-page placeholder';
        pageOld.id = `page-old-${idx}`;
        pageOld.dataset.index = idx;
        pageOld.style.minHeight = '800px';
        pageOld.style.width = '600px';
        containerOld.appendChild(pageOld);

        // Create Right Placeholder
        const pageNew = document.createElement('div');
        pageNew.className = 'pdf-page placeholder';
        pageNew.id = `page-new-${idx}`;
        pageNew.dataset.index = idx;
        pageNew.style.minHeight = '800px';
        pageNew.style.width = '600px';
        containerNew.appendChild(pageNew);

        if (page.has_diff) {
            state.metrics.changes++;
        }
    });

    updateSummary();
    setupObserver();
}

function updateSummary() {
    document.getElementById('totalPages').innerText = state.metrics.pages;
    document.getElementById('totalChanges').innerText = state.metrics.changes;
    document.getElementById('navMaxPages').innerText = state.metrics.pages;
    document.getElementById('pageCountOld').innerText = `Pages 1 to ${state.metrics.pages}`;
    document.getElementById('pageCountNew').innerText = `Pages 1 to ${state.metrics.pages}`;
}

function setupObserver() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const idx = parseInt(entry.target.dataset.index);
                loadPage(idx);
                observer.unobserve(entry.target);
            }
        });
    }, { root: null, rootMargin: '400px', threshold: 0.1 });

    document.querySelectorAll('.pdf-page.placeholder').forEach(p => observer.observe(p));
}

async function loadPage(idx) {
    const oldNode = document.getElementById(`page-old-${idx}`);
    const newNode = document.getElementById(`page-new-${idx}`);

    try {
        const response = await fetch(`/page/${state.sessionId}/${idx + 1}`);
        const data = await response.json();

        if (data.img_old) oldNode.innerHTML = `<img src="data:image/png;base64,${data.img_old}" style="width:100%" class="fade-in">`;
        if (data.img_new) newNode.innerHTML = `<img src="data:image/png;base64,${data.img_new}" style="width:100%" class="fade-in">`;

        if (data.text_diff) {
            processTextDiffs(data.text_diff, idx);
        }

        oldNode.classList.remove('placeholder');
        newNode.classList.remove('placeholder');
    } catch (err) {
        console.error('Failed to load page', idx, err);
    }
}

function processTextDiffs(diffs, pageIdx) {
    const changesList = document.getElementById('changesList');

    // Group diffs into logical changes for cards
    diffs.forEach(d => {
        const type = d[0];
        const text = d[1].trim();
        if (!text) return;

        if (type === 1) { // Insert
            state.metrics.inserts++;
            addChangeCard(pageIdx, 'ADDED', null, text);
        } else if (type === -1) { // Delete
            state.metrics.deletes++;
            addChangeCard(pageIdx, 'REMOVED', text, null);
        }

        // Update live metrics
        document.getElementById('totalInserts').innerText = state.metrics.inserts;
        document.getElementById('totalDeletes').innerText = state.metrics.deletes;
    });
}

function addChangeCard(pageIdx, type, before, after) {
    const list = document.getElementById('changesList');
    const card = document.createElement('div');
    card.className = 'change-card fade-in';

    let labelClass = 'label-replaced';
    if (type === 'ADDED') labelClass = 'label-added';
    if (type === 'REMOVED') labelClass = 'label-removed';

    card.innerHTML = `
        <div class="change-label ${labelClass}">${type}</div>
        ${before ? `<div class="card-text"><b>Before:</b><div class="snippet-del">${before}</div></div>` : ''}
        ${after ? `<div class="card-text"><b>After:</b><div class="snippet-ins">${after}</div></div>` : ''}
    `;

    card.onclick = () => scrollToPage(pageIdx);
    list.appendChild(card);

    // Update total change count in sidebar
    const count = list.children.length;
    document.getElementById('changeCounter').innerText = `1 of ${count}`;
}

function scrollToPage(index) {
    const paneOld = document.getElementById('paneOld');
    const paneNew = document.getElementById('paneNew');
    const target = document.getElementById(`page-old-${index}`);
    if (target) {
        paneOld.scrollTo({ top: target.offsetTop - 20, behavior: 'smooth' });
        paneNew.scrollTop = target.offsetTop - 20;
    }
}

// Sync Scrolling
const paneOld = document.getElementById('paneOld');
const paneNew = document.getElementById('paneNew');
let isScrolling = false;

paneOld.onscroll = () => {
    if (!isScrolling) {
        isScrolling = true;
        paneNew.scrollTop = paneOld.scrollTop;
        setTimeout(() => isScrolling = false, 50);
    }
};

paneNew.onscroll = () => {
    if (!isScrolling) {
        isScrolling = true;
        paneOld.scrollTop = paneNew.scrollTop;
        setTimeout(() => isScrolling = false, 50);
    }
};

document.getElementById('newComparison').onclick = () => location.reload();
