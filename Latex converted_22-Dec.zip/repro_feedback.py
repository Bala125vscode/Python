import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '.')))
from app.converter import LatexConverter

def test_repro():
    conv = LatexConverter()
    
    # Test case 1: Double wrapping (from feedback)
    inp1 = r"$\num{5408} - \num{4025.56} =  \qty{1382.44}{\kilo\electronvolt}$"
    expected1 = r"$5408 - 4025.56 =  1382.44\,\mathrm{keV}$"
    out1 = conv.convert(inp1)
    print(f"Test 1 (Double Wrapping): {inp1}")
    print(f"Got:    {out1}")
    assert out1 == expected1, f"Expected {expected1}, got {out1}"

    # Test case 2: Missing mathrm (from feedback)
    inp2 = r"\unit{n/cm^3} and \unit{cm/s}"
    expected2 = r"$\mathrm{n}/\mathrm{cm}^3$ and $\mathrm{cm}/\mathrm{s}$"
    out2 = conv.convert(inp2)
    print(f"\nTest 2 (Literal Units): {inp2}")
    print(f"Got:    {out2}")
    assert out2 == expected2, f"Expected {expected2}, got {out2}"

    # Test case 3: Robust Math Stack
    inp3 = r"\( \num{5} and $ \qty{10}{\meter} $ and \num{15} \)"
    expected3 = r"\( 5 and $ 10\,\mathrm{m} $ and 15 \)"
    out3 = conv.convert(inp3)
    print(f"\nTest 3 (Math Stack): {inp3}")
    print(f"Got:    {out3}")
    assert out3 == expected3, f"Expected {expected3}, got {out3}"

    # Test case 4: Escaped \$
    inp4 = r"Cost is \$10. \num{5} units."
    expected4 = r"Cost is \$10. $5$ units."
    out4 = conv.convert(inp4)
    print(f"\nTest 4 (Escaped $): {inp4}")
    print(f"Got:    {out4}")
    assert out4 == expected4, f"Expected {expected4}, got {out4}"

    print("\nALL REPRO TESTS PASSED!")

if __name__ == "__main__":
    test_repro()
