
import sys
import os
import traceback

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from app.converter import LatexConverter

def fuzz():
    c = LatexConverter()
    
    test_inputs = [
        "",
        "   ",
        "\\unit",
        "\\unit{",
        "\\unit{}",
        "\\unit{\\meter}",
        "\\unit{\\meter\\per}", 
        "\\unit{\\meter\\per\\second}",
        "\\unit{\\per\\square}",
        "\\unit{\\tothe}",
        "\\unit{\\tothe{5}}",
        "\\unit{\\meter\\tothe}",
        "\\qty",
        "\\qty{}",
        "\\qty{10}",
        "\\qty{10}{}",
        "\\qty{10}{\\meter}",
        "\\num",
        "\\num{}",
        # Tricky ones
        "\\unit{\\text{foo}}",
        "\\unit{\\unknown}",
        "\\unit{\\per\\unknown}",
        r"\unit{\henry\tothe{5}}",
        r"\unit{\raiseto{4.5}\radian}",
        r"\unit{\per\henry\tothe{5}}",
        r"\unit{\per\square\becquerel}",
    ]

    for inp in test_inputs:
        print(f"Testing input: '{inp}'")
        try:
            res = c.convert(inp)
            print(f"  Result: '{res}'")
        except Exception:
            print(f"CRASH on input: '{inp}'")
            traceback.print_exc()

if __name__ == "__main__":
    fuzz()
