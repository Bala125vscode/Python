
import time
import os
import sys

# Add app to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app.converter import LatexConverter

def test_large_conversion():
    input_file = "tests/large_test.tex"
    if not os.path.exists(input_file):
        print(f"File {input_file} not found. Generate it first.")
        return

    with open(input_file, "r", encoding="utf-8") as f:
        content = f.read()
    
    converter = LatexConverter()
    
    print(f"Converting {len(content)} characters / {len(content.splitlines())} lines...")
    start_time = time.time()
    converted_content = converter.convert(content)
    end_time = time.time()
    
    duration = end_time - start_time
    print(f"Conversion took {duration:.4f} seconds.")
    
    # Basic Validation
    assert r"\qty" not in converted_content
    assert r"\num" not in converted_content
    # Note: Physics commands like \dv might be replaced by \frac or partials, but checking strict absence 
    # might be tricky if they are inside text, but we expect full conversion.
    assert r"\dv" not in converted_content
    
    output_file = "tests/large_test_converted.tex"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(converted_content)
    print(f"Saved converted output to {output_file}")

if __name__ == "__main__":
    test_large_conversion()
