from app.converter import LatexConverter
import pytest

def test_num_conversion():
    c = LatexConverter()
    assert c.convert(r"\num{1.23}") == "1.23"
    assert c.convert(r"\num{1.23e4}") == r"1.23 \times 10^{4}"

def test_unit_conversion():
    c = LatexConverter()
    assert c.convert(r"\unit{\meter\per\second}") == r"\mathrm{m}/\mathrm{s}"
    assert c.convert(r"\si{\kg}") == r"\mathrm{kg}"
    # Test with optional arg
    assert c.convert(r"\unit[per-mode = symbol]{\kilogram\metre\per\ampere\per\second}") == r"\mathrm{kg}\mathrm{m}/\mathrm{A}/\mathrm{s}"

def test_qty_conversion():
    c = LatexConverter()
    assert c.convert(r"\qty{5}{\meter}") == r"5\,\mathrm{m}"
    assert c.convert(r"\qty{1.2e3}{\joule}") == r"1.2 \times 10^{3}\,\mathrm{J}"

def test_complex_num():
    c = LatexConverter()
    assert c.convert(r"\complexnum{1+-2i}") == r"1+-2\mathrm{i}"
    
def test_num_product():
    c = LatexConverter()
    assert c.convert(r"\numproduct{1.654 x 2.34 x 3.430}") == r"1.654 \times 2.34 \times 3.430"

def test_list_and_range():
    c = LatexConverter()
    assert c.convert(r"\numlist{10;20;30}") == r"10, 20 \text{ and } 30"
    assert c.convert(r"\qtylist{0.13;0.67;0.80}{\milli\metre}") == r"0.13, 0.67 \text{ and } 0.80\,\mathrm{m}\mathrm{m}" # \milli -> m 
    assert c.convert(r"\numrange{10}{20}") == r"10 \text{--} 20"
    assert c.convert(r"\qtyrange{0.13}{0.67}{\milli\metre}") == r"0.13 \text{--} 0.67\,\mathrm{m}\mathrm{m}"

def test_physics_derivatives():
    c = LatexConverter()
    assert c.convert(r"\dv{x}") == r"\frac{\mathrm{d}}{\mathrm{d}x}"
    assert c.convert(r"\dv{f}{x}") == r"\frac{\mathrm{d} f}{\mathrm{d}x}"
    assert c.convert(r"\dv[2]{f}{x}") == r"\frac{\mathrm{d}^2 f}{\mathrm{d}x^2}"
    
def test_physics_partials():
    c = LatexConverter()
    assert c.convert(r"\pdv{f}{x}") == r"\frac{\partial f}{\partial x}"
    
def test_text_mixed():
    c = LatexConverter()
    text = r"The length is \qty{5}{\meter} and velocity is \dv{x}{t}."
    expected = r"The length is 5\,\mathrm{m} and velocity is \frac{\mathrm{d} x}{\mathrm{d}t}."
    assert c.convert(text) == expected
