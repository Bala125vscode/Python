import fitz  # PyMuPDF
from diff_match_patch import diff_match_patch
from PIL import Image, ImageChops
import io
import base64

class PDFCompareEngine:
    def __init__(self):
        self.dmp = diff_match_patch()

    def get_text_diff(self, text1, text2):
        diffs = self.dmp.diff_main(text1, text2)
        self.dmp.diff_cleanupSemantic(diffs)
        return diffs

    def analyze_documents(self, file1_path, file2_path):
        d1 = fitz.open(file1_path)
        d2 = fitz.open(file2_path)
        results = []
        num_pages = max(len(d1), len(d2))
        for i in range(num_pages):
            page_data = {"page_num": i + 1, "has_diff": False, "status": "Equal"}
            p1 = d1[i] if i < len(d1) else None
            p2 = d2[i] if i < len(d2) else None
            if p1 and p2:
                if p1.get_text() != p2.get_text():
                    page_data["has_diff"] = True
                    page_data["status"] = "Changed"
                else:
                    pix1 = p1.get_pixmap(matrix=fitz.Matrix(0.2, 0.2))
                    pix2 = p2.get_pixmap(matrix=fitz.Matrix(0.2, 0.2))
                    if pix1.tobytes() != pix2.tobytes():
                        page_data["has_diff"] = True
                        page_data["status"] = "Changed"
            elif p1:
                page_data["has_diff"] = True
                page_data["status"] = "Deleted"
            else:
                page_data["has_diff"] = True
                page_data["status"] = "Added"
            results.append(page_data)
        d1.close()
        d2.close()
        return results

    def _get_char_stream(self, page):
        """Highly accurate character stream extraction for diff alignment."""
        char_data = []
        raw = page.get_text("rawdict")
        last_x1 = -1
        last_y1 = -1
        
        for block in raw["blocks"]:
            if "lines" not in block: continue
            for line in block["lines"]:
                # Check for vertical gap (new block/line)
                if last_y1 != -1 and line["bbox"][1] > last_y1 + 2:
                    # Inject a virtual newline with no physical bbox area to avoid vertical highlights
                    char_data.append({"c": "\n", "bbox": None})
                
                for span in line["spans"]:
                    for char in span["chars"]:
                        c = char["c"]
                        bbox = list(char["bbox"])
                        
                        # Check for horizontal gap (inject space if missing)
                        if last_x1 != -1 and bbox[0] > last_x1 + 3 and c != " " and last_y1 != -1 and abs(bbox[1] - last_y1) < 5:
                            char_data.append({"c": " ", "bbox": [last_x1, bbox[1], bbox[0], bbox[3]]})
                        
                        char_data.append({"c": c, "bbox": bbox})
                        last_x1 = bbox[2]
                        last_y1 = bbox[3]
                
                # Force line break after line
                if char_data and char_data[-1]["c"] != "\n":
                    char_data.append({"c": "\n", "bbox": None})
        
        text = "".join([d["c"] for d in char_data])
        bboxes = [d["bbox"] for d in char_data]
        return text, bboxes

    def _merge_rects(self, rects):
        # Filter out None bboxes (newlines)
        rects = [r for r in rects if r is not None]
        if not rects: return []
        merged = []
        current = list(rects[0])
        for i in range(1, len(rects)):
            r = rects[i]
            # Merge if same line and horizontally close
            if abs(r[1] - current[1]) < 3 and r[0] < current[2] + 10:
                current[0] = min(current[0], r[0])
                current[1] = min(current[1], r[1])
                current[2] = max(current[2], r[2])
                current[3] = max(current[3], r[3])
            else:
                merged.append(current)
                current = list(r)
        merged.append(current)
        return merged

    def get_page_details(self, file1_path, file2_path, page_idx):
        doc1 = fitz.open(file1_path)
        doc2 = fitz.open(file2_path)
        
        page_data = {
            "width": 0, "height": 0,
            "img_old": None, "img_new": None,
            "h_old": [], "h_new": [], # List of {uid, rects}
            "text_diff": [] # Enhanced with uid
        }

        p1 = doc1[page_idx] if page_idx < len(doc1) else None
        p2 = doc2[page_idx] if page_idx < len(doc2) else None
        
        if p1: page_data["width"], page_data["height"] = p1.rect.width, p1.rect.height
        elif p2: page_data["width"], page_data["height"] = p2.rect.width, p2.rect.height

        mat = fitz.Matrix(2.0, 2.0)
        if p1: page_data["img_old"] = base64.b64encode(p1.get_pixmap(matrix=mat).tobytes()).decode()
        if p2: page_data["img_new"] = base64.b64encode(p2.get_pixmap(matrix=mat).tobytes()).decode()

        if p1 and p2:
            text1, bboxes1 = self._get_char_stream(p1)
            text2, bboxes2 = self._get_char_stream(p2)
            
            raw_diffs = self.get_text_diff(text1, text2)
            
            idx1, idx2 = 0, 0
            change_count = 0
            
            for tag, chunk in raw_diffs:
                char_len = len(chunk)
                uid = f"p{page_idx}_{change_count}"
                
                if tag == 0: # Equal
                    idx1 += char_len
                    idx2 += char_len
                elif tag == -1: # Removed
                    change_count += 1
                    chunk_rects = bboxes1[idx1 : idx1 + char_len]
                    merged = self._merge_rects(chunk_rects)
                    # Robustness: Only show changes that contain non-whitespace text
                    if chunk.strip():
                        page_data["h_old"].append({"uid": uid, "rects": merged})
                        page_data["text_diff"].append({"tag": -1, "text": chunk, "uid": uid})
                    idx1 += char_len
                elif tag == 1: # Added
                    change_count += 1
                    chunk_rects = bboxes2[idx2 : idx2 + char_len]
                    merged = self._merge_rects(chunk_rects)
                    # Robustness: Only show changes that contain non-whitespace text
                    if chunk.strip():
                        page_data["h_new"].append({"uid": uid, "rects": merged})
                        page_data["text_diff"].append({"tag": 1, "text": chunk, "uid": uid})
                    idx2 += char_len

        doc1.close()
        doc2.close()
        return page_data
