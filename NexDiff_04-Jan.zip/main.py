from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
import os
import shutil
import uuid
from compare_engine import PDFCompareEngine

app = FastAPI()

# Enable CORS for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "uploads"
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR)

engine = PDFCompareEngine()

@app.post("/compare")
async def compare_pdfs(file1: UploadFile = File(...), file2: UploadFile = File(...)):
    session_id = str(uuid.uuid4())
    session_dir = os.path.join(UPLOAD_DIR, session_id)
    os.makedirs(session_dir)
    
    path1 = os.path.join(session_dir, "old.pdf")
    path2 = os.path.join(session_dir, "new.pdf")
    
    with open(path1, "wb") as buffer:
        shutil.copyfileobj(file1.file, buffer)
    with open(path2, "wb") as buffer:
        shutil.copyfileobj(file2.file, buffer)
        
    try:
        results = engine.analyze_documents(path1, path2)
        return JSONResponse(content={"session_id": session_id, "comparison": results})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/page/{session_id}/{page_num}")
async def get_page(session_id: str, page_num: int):
    session_dir = os.path.join(UPLOAD_DIR, session_id)
    path1 = os.path.join(session_dir, "old.pdf")
    path2 = os.path.join(session_dir, "new.pdf")
    
    if not os.path.exists(path1) or not os.path.exists(path2):
        raise HTTPException(status_code=404, detail="Session or files not found")
        
    try:
        # page_num is 1-indexed from frontend
        details = engine.get_page_details(path1, path2, page_num - 1)
        return JSONResponse(content=details)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/style.css")
async def get_style():
    return FileResponse("style.css")

@app.get("/app.js")
async def get_app():
    return FileResponse("app.js")

@app.get("/", response_class=HTMLResponse)
async def get_index():
    return FileResponse("index.html")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
