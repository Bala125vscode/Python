from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
import os

def create_presentation():
    prs = Presentation()

    # Slide 1: Title Slide
    slide_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    subtitle = slide.placeholders[1]
    title.text = "NexDiff"
    subtitle.text = "Precision PDF Comparison & Analysis System\nHigh-Quality, Character-Level Accuracy"

    # Slide 2: Problem Statement
    slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    title.text = "The Challenge"
    content = slide.placeholders[1]
    content.text = ("Traditional PDF comparison suffers from:\n"
                    "• Inaccurate text alignment.\n"
                    "• Ghost highlights due to space drift.\n"
                    "• Static interfaces that lack interaction.\n"
                    "• Difficult navigation in large documents.")

    # Slide 3: Key Features (Part 1)
    slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    title.text = "Core Innovation"
    content = slide.placeholders[1]
    content.text = ("1. Space-Aware Character Extraction\n"
                    "• Tracks every character and gap with 100% precision.\n"
                    "• No index drift across spaces or line breaks.\n\n"
                    "2. Bidirectional Selection\n"
                    "• Click any highlight on PDF → Jump to sidebar card.\n"
                    "• Click sidebar card → Precise scroll and glow on PDF.")

    # Slide 4: Key Features (Part 2)
    slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    title.text = "Premium User Experience"
    content = slide.placeholders[1]
    content.text = ("• Multi-Page Grouping: Sidebars organized by page headers.\n"
                    "• Synchronized Scrolling: Side-by-side comparison stay in sync.\n"
                    "• Visual Clarity: Merged rectangles for clean word-level highlights.\n"
                    "• Modern UI: Professional light theme inspired by global standards.")

    # Slide 5: Tech Stack
    slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    title.text = "Technology Stack"
    content = slide.placeholders[1]
    content.text = ("Backend:\n"
                    "• Python 3.11 with FastAPI\n"
                    "• PyMuPDF (Fitz) for high-performance PDF rendering\n"
                    "• Google Diff-Match-Patch for text analysis\n\n"
                    "Frontend:\n"
                    "• Vanilla JavaScript, HTML5, CSS3\n"
                    "• IntersectionObserver for lazy loading performance\n"
                    "• Lucide Icons for professional branding")

    # Slide 6: Visual Demo (Placeholder/Text)
    slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    title.text = "Visual Comparison Interface"
    content = slide.placeholders[1]
    content.text = ("Dynamic rendering of semi-transparent overlays:\n"
                    "• Red highlights for deleted content.\n"
                    "• Green highlights for newly inserted content.\n"
                    "• Golden glow for currently active/selected correction.")
    
    img_path = r"C:\Users\Lenovo\.gemini\antigravity\brain\43b339ec-2e00-494d-9e17-135a2a62c821\nexdiff_selection_final_1767323958790.png"
    if os.path.exists(img_path):
        prs.slides[5].shapes.add_picture(img_path, Inches(0.5), Inches(3.5), width=Inches(9))

    # Save
    ppt_path = "NexDiff_Presentation.pptx"
    prs.save(ppt_path)
    print(f"Presentation saved to {os.path.abspath(ppt_path)}")

if __name__ == "__main__":
    create_presentation()
