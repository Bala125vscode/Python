const state = {
    fileOld: null,
    fileNew: null,
    results: null,
    sessionId: null,
    metrics: {
        pages: 0,
        changes: 0,
        inserts: 0,
        deletes: 0
    },
    pageGroups: {},
    activeUid: null
};

// DOM Elements
const dropOld = document.getElementById('dropOld');
const dropNew = document.getElementById('dropNew');
const inputOld = document.getElementById('inputOld');
const inputNew = document.getElementById('inputNew');
const nameOld = document.getElementById('nameOld');
const nameNew = document.getElementById('nameNew');
const startBtn = document.getElementById('startCompare');
const modal = document.getElementById('uploadModal');
const loader = document.getElementById('loader');

if (dropOld) dropOld.onclick = () => { if (inputOld) inputOld.click(); };
if (dropNew) dropNew.onclick = () => { if (inputNew) inputNew.click(); };
if (inputOld) inputOld.onchange = (e) => handleFile(e.target.files[0], 'old');
if (inputNew) inputNew.onchange = (e) => handleFile(e.target.files[0], 'new');

[dropOld, dropNew].forEach(zone => {
    if (!zone) return;
    zone.ondragover = (e) => { e.preventDefault(); zone.style.borderColor = 'var(--accent-blue)'; zone.style.background = '#f0f7ff'; };
    zone.ondragleave = () => { zone.style.borderColor = 'var(--border-light)'; zone.style.background = 'transparent'; };
    zone.ondrop = (e) => {
        e.preventDefault();
        zone.style.borderColor = 'var(--border-light)'; zone.style.background = 'transparent';
        handleFile(e.dataTransfer.files[0], zone === dropOld ? 'old' : 'new');
    };
});

function handleFile(file, type) {
    if (!file) return;
    const nameEl = type === 'old' ? nameOld : nameNew;
    const labelId = type === 'old' ? 'labelOld' : 'labelNew';
    if (type === 'old') state.fileOld = file; else state.fileNew = file;
    nameEl.innerText = file.name;
    document.getElementById(labelId).innerText = file.name;
    startBtn.disabled = !(state.fileOld && state.fileNew);
}

startBtn.onclick = async () => {
    loader.style.display = 'flex';
    const fd = new FormData();
    fd.append('file1', state.fileOld);
    fd.append('file2', state.fileNew);
    try {
        const res = await fetch('/compare', { method: 'POST', body: fd });
        const data = await res.json();
        renderResults(data);
        modal.style.display = 'none';
    } catch (err) { alert('Failed: ' + err.message); }
    finally { loader.style.display = 'none'; }
};

function renderResults(data) {
    state.sessionId = data.session_id;
    state.results = data.comparison;
    state.pageGroups = {};
    const cOld = document.getElementById('containerOld');
    const cNew = document.getElementById('containerNew');
    const list = document.getElementById('changesList');
    cOld.innerHTML = cNew.innerHTML = list.innerHTML = '';
    state.metrics = { pages: state.results.length, changes: 0, inserts: 0, deletes: 0 };

    state.results.forEach((page, idx) => {
        const create = (cont, side) => {
            const w = document.createElement('div');
            w.className = 'pdf-page-wrapper placeholder';
            w.id = `wrapper-${side}-${idx}`;
            w.dataset.index = idx;
            w.style.minHeight = '800px';
            w.style.width = '600px';
            cont.appendChild(w);
        };
        create(cOld, 'old');
        create(cNew, 'new');
        if (page.has_diff) state.metrics.changes++;
    });
    updateSummary();
    setupObserver();
}

function updateSummary() {
    document.getElementById('totalPages').innerText = state.metrics.pages;
    document.getElementById('totalChanges').innerText = state.metrics.changes;
    document.getElementById('navMaxPages').innerText = state.metrics.pages;
}

function setupObserver() {
    const obs = new IntersectionObserver(entries => {
        entries.forEach(e => {
            if (e.isIntersecting) {
                const idx = parseInt(e.target.dataset.index);
                loadPage(idx);
                obs.unobserve(e.target);
            }
        });
    }, { rootMargin: '800px' });
    document.querySelectorAll('.pdf-page-wrapper.placeholder').forEach(p => obs.observe(p));
}

async function loadPage(idx) {
    const wrapO = document.getElementById(`wrapper-old-${idx}`);
    const wrapN = document.getElementById(`wrapper-new-${idx}`);
    const res = await fetch(`/page/${state.sessionId}/${idx + 1}`);
    const data = await res.json();

    const scale = 600 / data.width;
    const h = data.height * scale;
    [wrapO, wrapN].forEach(w => { w.style.height = h + 'px'; w.classList.remove('placeholder'); });

    if (data.img_old) wrapO.innerHTML = `<img src="data:image/png;base64,${data.img_old}" class="pdf-page">`;
    if (data.img_new) wrapN.innerHTML = `<img src="data:image/png;base64,${data.img_new}" class="pdf-page">`;

    renderHighlights(wrapO, data.h_old, 'h-del', scale);
    renderHighlights(wrapN, data.h_new, 'h-ins', scale);

    if (data.text_diff) {
        data.text_diff.forEach(d => {
            // Robustness: Only show changes that contain meaningful text
            if (d.text && d.text.trim().length > 0) {
                if (d.tag === 1) state.metrics.inserts++; else state.metrics.deletes++;
                addChangeCard(idx, d);
            }
        });
        document.getElementById('totalInserts').innerText = state.metrics.inserts;
        document.getElementById('totalDeletes').innerText = state.metrics.deletes;
    }
}

function renderHighlights(container, items, className, scale) {
    const overlay = document.createElement('div');
    overlay.className = 'highlight-overlay';
    items.forEach(item => {
        item.rects.forEach(r => {
            const w = (r[2] - r[0]) * scale;
            const h = (r[3] - r[1]) * scale;

            // Robustness: Filter out "junk" highlights (like vertical lines < 2px wide)
            if (w < 1 || h < 1) return;

            const el = document.createElement('div');
            el.className = `h-rect ${className}`;
            el.dataset.uid = item.uid;
            el.style.left = (r[0] * scale) + 'px';
            el.style.top = (r[1] * scale) + 'px';
            el.style.width = Math.max(2, w) + 'px';
            el.style.height = Math.max(2, h) + 'px';
            el.onclick = (e) => { e.stopPropagation(); selectChange(item.uid); };
            overlay.appendChild(el);
        });
    });
    container.appendChild(overlay);
}

function addChangeCard(idx, diff) {
    const list = document.getElementById('changesList');
    if (!state.pageGroups[idx]) {
        const h = document.createElement('div');
        h.className = 'sidebar-page-header';
        h.innerText = `PAGE ${idx + 1}`;
        h.onclick = () => scrollToPage(idx);

        let inserted = false;
        const headers = list.querySelectorAll('.sidebar-page-header');
        for (let entry of headers) {
            const eIdx = parseInt(entry.innerText.replace('PAGE ', '')) - 1;
            if (eIdx > idx) { list.insertBefore(h, entry); inserted = true; break; }
        }
        if (!inserted) list.appendChild(h);
        state.pageGroups[idx] = h;
    }

    const card = document.createElement('div');
    card.className = 'change-card';
    card.id = `card-${diff.uid}`;
    const type = diff.tag === 1 ? 'ADDED' : 'REMOVED';
    const lClass = diff.tag === 1 ? 'label-added' : 'label-removed';

    card.innerHTML = `
        <div class="change-label ${lClass}">${type}</div>
        <div class="card-text"><b>${diff.tag === 1 ? 'After' : 'Before'}:</b><div class="snippet-${diff.tag === 1 ? 'ins' : 'del'}">${escapeHtml(diff.text)}</div></div>
    `;
    card.onclick = () => selectChange(diff.uid);
    state.pageGroups[idx].after(card);
    document.getElementById('changeCounter').innerText = `${list.querySelectorAll('.change-card').length} total changes`;
}

function selectChange(uid) {
    // Clear previous
    document.querySelectorAll('.h-rect.active, .change-card.active').forEach(el => el.classList.remove('active'));

    state.activeUid = uid;
    const card = document.getElementById(`card-${uid}`);
    if (card) {
        card.classList.add('active');
        card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    const highlights = document.querySelectorAll(`[data-uid="${uid}"]`);
    highlights.forEach(h => h.classList.add('active'));

    if (highlights.length > 0) {
        const first = highlights[0];
        const pane = first.closest('.pdf-pane');
        if (pane) {
            pane.scrollTo({ top: first.offsetTop - 100, behavior: 'smooth' });
        }
    }
}

function escapeHtml(t) { const d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
function scrollToPage(i) { const p = document.getElementById('paneOld'); const t = document.getElementById(`wrapper-old-${i}`); if (t) p.scrollTo({ top: t.offsetTop, behavior: 'smooth' }); }

const pO = document.getElementById('paneOld'), pN = document.getElementById('paneNew');
let isS = false;
pO.onscroll = () => { if (!isS) { isS = true; pN.scrollTop = pO.scrollTop; setTimeout(() => isS = false, 20); } };
pN.onscroll = () => { if (!isS) { isS = true; pO.scrollTop = pN.scrollTop; setTimeout(() => isS = false, 20); } };
document.getElementById('newComparison').onclick = () => location.reload();
if (window.lucide) lucide.createIcons();
